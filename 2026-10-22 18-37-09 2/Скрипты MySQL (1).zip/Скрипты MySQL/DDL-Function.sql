use sale_product_database;
select Name_Manufacturer as "Производитель", length(Name_Manufacturer) as "Количество символов", group_concat(Product_Name) as "Cписок постовляемой продукции", count(Manufacturer_ID) as "Количество поставляемой продукции" from Product
inner join Manufacturer on ID_Manufacturer = Manufacturer_ID
group by Name_Manufacturer;

select Product_Name as "Самый продоваемый продукт", sum(Sale_Check_View_Ammount) as "Количество проданных позиций" from Product
inner join Sale_Check_View on Product_ID = ID_Product
group by Product_Name
having sum(Sale_Check_View_Ammount) > 1
limit 3;

select Concat('Номер карты: ',Card_Number, ', держатель карты: ', Card_Holder, ' ФИО Покупателя ', First_Name_Buyer,' ',SUBSTRING(Second_Name_Buyer,1,1),'.',SUBSTRING(Middle_Name_Buyer,1,1),'.') as "Данные покупателя",
Round(avg(Whith_VAT),2) as "Средняя цена чека" from Buyer
inner join Buyer_Card on ID_Buyer = Buyer_ID
inner join Sale_Check on ID_Buyer_Card = Buyer_Card_ID
group by Concat('Номер карты: ',Card_Number, ', держатель карты: ', Card_Holder, 'ФИО Покупателя ', First_Name_Buyer,' ',SUBSTRING(Second_Name_Buyer from 1 for 1),'.',SUBSTRING(Middle_Name_Buyer from 1 for 1),'.');

select Product_Name as "Название продукта", case 
	when Price_Product < 150 then 'Дешёвый товар'
	when Price_Product between 150 and 500 then 'Доступный товар'
	when Price_Product > 500 then 'Дорогой товар' 
	end as "Степень дороговизны" from Product;

select Max(Price_Product) as "Самый дорогой товар", MIN(Price_Product) as "Самый дешёвый товар" from Product;

select LOWER(Name_Suppler) as "Вид Юр. Лица", UPPER(Full_Name_Suppler) as "Название огранизации", 
date_format(Date_Create_Term,'%d.%m.%Y')  as "Дата заключения договора" , 
date_format(date_add(Date_Create_Term, interval SUBSTRING(Term, 1,3) year),'%d.%m.%Y')  as "Дата окончания договора" ,
timestampdiff(year , current_date, date_add(Date_Create_Term, interval SUBSTRING(Term, 1,3) year))  as "Продолжительность действия договора в годах" , 
extract(quarter from date_add(Date_Create_Term, interval SUBSTRING(Term, 1,3) year))  as "Квартал окончания договора" from Treaty
inner join Representative on ID_Representative = Representative_ID
inner join Suppler on ID_Suppler = Suppler_ID
inner join Type_Suppler on ID_Type_Suppler = Type_Suppler_ID;

select distinct(Date_Create_Supply) from Supply;

select ROW_NUMBER() over (order by Date_Create_Check) as "№ строки", Sale_Check_Number as "№ чека" from Product
inner join Sale_Check_View on Product_ID = ID_Product
inner join Sale_Check on ID_Sale_Check = Sale_Check_ID;

DELIMITER //
create function Buyer_Card_Money(p_Card_Number varchar (19)) 
returns decimal (38,2)
deterministic
	begin
		declare p_Price decimal (38,2);
		select sum(Without_VAT) into p_Price from Sale_Check
		inner join Buyer_Card on Buyer_Card_ID = ID_Buyer_Card
		where Card_Number = p_Card_Number;
		return p_Price;
	end;
DELIMITER /

select Buyer_Card_Money('5542 5674 9974 8974');

SELECT count(*) FROM  information_schema.routines 
WHERE routine_type = 'FUNCTION' and routine_schema = 'sale_product_database';