select Name_Manufacturer as "Производитель", length(Name_Manufacturer) as "Количество символов", STRING_AGG(Product_Name, ', ') as "Cписок постовляемой продукции", count(Manufacturer_ID) as "Количество поставляемой продукции" from Product
inner join Manufacturer on ID_Manufacturer = Manufacturer_ID
group by Name_Manufacturer;

select Product_Name as "Самый продоваемый продукт", sum(Sale_Check_View_Ammount) as "Количество проданных позиций" from Product
inner join Sale_Check_View on Product_ID = ID_Product
group by Product_Name
having sum(Sale_Check_View_Ammount) > 1
limit 3;

select Concat('Номер карты: ',Card_Number, ', держатель карты: ', Card_Holder, 'ФИО Покупателя ', First_Name_Buyer,' ',SUBSTRING(Second_Name_Buyer from 1 for 1),'.',SUBSTRING(Middle_Name_Buyer from 1 for 1),'.') as "Данные покупателя",
Round(avg(Whith_VAT),2) as "Средняя цена чека" from Buyer
inner join Buyer_Card on ID_Buyer = Buyer_ID
inner join Sale_Check on ID_Buyer_Card = Buyer_Card_ID
group by Concat('Номер карты: ',Card_Number, ', держатель карты: ', Card_Holder, 'ФИО Покупателя ', First_Name_Buyer,' ',SUBSTRING(Second_Name_Buyer from 1 for 1),'.',SUBSTRING(Middle_Name_Buyer from 1 for 1),'.');

select Product_Name as "Название продукта", case 
	when Price_Product < 150 then 'Дешёвый товар'
	when Price_Product between 150 and 500 then 'Доступный товар'
	when Price_Product > 500 then 'Дорогой товар' 
	end as "Степень дороговизны" from Product;

select Max(Price_Product) as "Самый дорогой товар", MIN(Price_Product) as "Самый дешёвый товар" from Product;

select LOWER(Name_Suppler) as "Вид Юр. Лица", UPPER(Full_Name_Suppler) as "Название огранизации", 
to_char(Date_Create_Term,'dd.MM.yyyy')  as "Дата заключения договора" , 
to_char(Date_Create_Term + interval '1 year'*SUBSTRING(Term, 0,3)::integer,'dd.MM.yyyy')  as "Дата окончания договора" ,
date_part('year', age(Date_Create_Term + interval '1 year'*SUBSTRING(Term, 0,3)::integer, current_date))  as "Продолжительность действия договора в годах" , 
date_part('QUARTER',Date_Create_Term + interval '1 year'*SUBSTRING(Term, 0,3)::integer)  as "Квартал окончания договора" from Treaty
inner join Representative on ID_Representative = Representative_ID
inner join Suppler on ID_Suppler = Suppler_ID
inner join Type_Suppler on ID_Type_Suppler = Type_Suppler_ID;

select distinct(Date_Create_Supply) from Supply;

select ROW_NUMBER() over (order by Date_Create_Check) as "№ строки", Sale_Check_Number as "№ чека" from Product
inner join Sale_Check_View on Product_ID = ID_Product
inner join Sale_Check on ID_Sale_Check = Sale_Check_ID;

create or replace function Buyer_Card_Money(p_Card_Number varchar (19)) 
returns decimal (38,2)
language plpgsql
as $$
	declare p_Price decimal (38,2);
	begin
		p_Price := sum(Without_VAT) from Sale_Check
		inner join Buyer_Card on Buyer_Card_ID = ID_Buyer_Card
		where Card_Number = p_Card_Number;
		return p_Price;
	end;
$$;

select Buyer_Card_Money('5542 5674 9974 8974');


create or replace function Sale_Check_History(p_Sale_Check_Number varchar (13))
returns table (check_date date, check_detail text, deposit_Ammount decimal (38,2), VAT decimal (38,2), difference decimal(38,2))
language plpgsql
as $$
	begin
		return query select Date_Create_Check as "№ Чека", 
		STRING_AGG('Позиция: '||Product_Name||', кол-во: '||Sale_Check_View_Ammount||', цена за единицу: '||Price_Product||' руб, общая цена: '||Sale_Check_View_Ammount*Price_Product,', '), 
		 Deposited_Ammount , Whith_VAT ,  Deposited_Ammount - Whith_VAT from Sale_Check
		 inner join Sale_Check_View on Sale_Check_ID = ID_Sale_Check
		 inner join Product on Product_ID = ID_Product
		 where Sale_Check_Number = p_Sale_Check_Number
		 group by Date_Create_Check, Deposited_Ammount, Whith_VAT;
	end;
$$;

select * from Sale_Check_History('0000000001-ФК');

SELECT count(*) FROM information_schema.routines 
WHERE routine_type = 'FUNCTION' AND routine_schema = 'public';
