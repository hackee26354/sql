create database Sale_Product_Database;
use Sale_Product_Database;

CREATE TABLE Type_Product
(
	ID_Type_Product int not null auto_increment PRIMARY KEY,
	Name_Type VARCHAR(50) not null UNIQUE
);

insert into type_product (name_type)
VALUES('Растворимый продукт'),
('Овощь'),
('Мясное изделье'),
('Молочная продукция');

SELECT name_type as "Название продукта" from type_product
order by name_type ASC;

CREATE TABLE Country
(
	ID_Country int not null auto_increment PRIMARY KEY,
	Name_Country VARCHAR(50) not null UNIQUE
);

insert into Country (Name_Country)
values ('Швейцария'),
('Россия');

select Name_Country as "Название страны" from Country
order by Name_Country ASC;

CREATE TABLE Market_Place
(
	ID_Market_Place int not null auto_increment PRIMARY KEY,
	Market_Address VARCHAR(400) not null UNIQUE
);

insert into Market_Place (Market_Address)
values ('ул. Чертановская, д.6, стр. 2'),
('ул. Волжская, д.10, к.1');

select Market_Address as "Адрес магазина" from Market_Place
order by Market_Address ASC;

CREATE TABLE Type_Suppler
(
	ID_Type_Suppler int not null auto_increment PRIMARY KEY,
	Name_Suppler VARCHAR(30) not null UNIQUE
);

insert into Type_Suppler (Name_Suppler)
values ('ООО'),
('НПАО'),
('ПАО');

select Name_Suppler as "Тип фирмы" from Type_Suppler
order by Name_Suppler DESC;

CREATE TABLE Payment_Type
(	
	ID_Payment_Type int not null auto_increment PRIMARY KEY,
	Name_Payment_Type VARCHAR (30) not null UNIQUE
);

insert into Payment_Type (Name_Payment_Type)
values ('Наличный'),
('Без наличный');

select Name_Payment_Type as "Тип оплаты" from Payment_Type
order by Name_Payment_Type ASC;

CREATE TABLE Post
(
	ID_Post int not null auto_increment PRIMARY KEY,
	Name_Post VARCHAR (50) not null UNIQUE
);

insert into Post(Name_Post)
values ('Продавец-Кассир'),
('Старший продaвец');

select Name_Post as "Название должности" from Post
order by Name_Post ASC;

CREATE TABLE Employee
(
	ID_Employee int not null auto_increment PRIMARY KEY,
	First_Name_Emp VARCHAR (30) not null,
	Second_Name_Emp VARCHAR (30) not null,
	Middle_Name_Emp VARCHAR (30) null DEFAULT '-',
	Key_Employee VARCHAR(10) null DEFAULT '-',
	Login_Employee VARCHAR(32) not null UNIQUE
	CONSTRAINT CH_Login_Employee CHECK (length(Login_Employee) >= 8),
	Password_Employee VARCHAR(32) not null CONSTRAINT CH_Password_Employee_UPPER
	CHECK (regexp_like(Password_Employee, '[A-Z]')) CONSTRAINT CH_Password_Employee_LOWER
	CHECK (regexp_like(Password_Employee, '[a-z]')) CONSTRAINT CH_Password_Employee_SYMBOL
	CHECK (regexp_like(Password_Employee, '[!@#$%^&*]'))
);

insert into Employee (First_Name_Emp, Second_Name_Emp, middle_name_emp, Login_Employee, Password_Employee)
values ('Павлов','Павел','Павлович','PavlovPP','Pa$$w0rd');
insert into Employee (First_Name_Emp, Second_Name_Emp, Middle_Name_Emp, Key_Employee,Login_Employee, Password_Employee)
values ('Дмитриев','Дмитрий','Дмитриевич','Rg63Frr!h','DmitriyDD','Pa$$w0rd');
insert into Employee (First_Name_Emp, Second_Name_Emp, Middle_Name_Emp, Login_Employee, Password_Employee)
values ('Олегов','Олег','Олегович','OlegovOO','Pa$$w0rd');

select concat(First_Name_Emp,' ',Second_Name_Emp,' ',Middle_Name_Emp) as "ФИО Сотрудника", Key_Employee as "Ключ отмены", Login_Employee as "Логин сотрудника", 
Password_Employee as "Пароль сотрудника" from Employee
order by First_Name_Emp ASC;

CREATE TABLE Cash_Machine
(
	ID_Cash_Machine int not null auto_increment PRIMARY KEY,
	Cash_Machine_Number VARCHAR(12) not null UNIQUE
	CONSTRAINT CH_Cash_Machine_Number 
	CHECK (regexp_like(Cash_Machine_Number, 'КА\\-[0-9]{8}'))
);

insert into Cash_Machine (Cash_Machine_Number)
values ('КА-00000001'),
('КА-00000002'),
('КА-00000003');

select Cash_Machine_Number as "Номер кассового аппарата" from Cash_Machine
order by Cash_Machine_Number ASC;

CREATE TABLE Buyer
(
	ID_Buyer int not null auto_increment PRIMARY KEY,
	First_Name_Buyer VARCHAR (30) not null,
	Second_Name_Buyer VARCHAR (30) not null,
	Middle_Name_Buyer VARCHAR (30) null DEFAULT '-',
	Login_Buyer VARCHAR(32) not null UNIQUE
	CONSTRAINT CH_Login_Buyer CHECK (length (Login_Buyer) >= 8),
	Password_Buyer VARCHAR(32) not null CONSTRAINT CH_Password_Buyer_UPPER
	CHECK (regexp_like(Password_Buyer, '[A-Z]')) CONSTRAINT CH_Password_Buyer_LOWER
	CHECK (regexp_like(Password_Buyer, '[a-z]')) CONSTRAINT CH_Password_Buyer_SYMBOL
	CHECK (regexp_like(Password_Buyer, '[!@#$%^&*]'))
);	

insert into Buyer (First_Name_Buyer, Second_Name_Buyer, Middle_Name_Buyer, Login_Buyer, Password_Buyer)
values ('Иванов','Иван','Иванович','IvanovII','Pa$$w0rd'),
('Петров','Пётр','Петрович','PetrovPP','Pa$$w0rd'),
('Андреев','Андрей','Андреевич','AndreevAA','Pa$$w0rd');

select Concat(First_Name_Buyer,' ',Second_Name_Buyer,' ',Middle_Name_Buyer) as "ФИО Клиента", Login_Buyer as "Логин покупателя", Password_Buyer as "Пароль покупателя" from Buyer
order by First_Name_Buyer ASC;

CREATE TABLE Product_List
(
	ID_Product_List int not null auto_increment PRIMARY KEY,
	Product_List_Number VARCHAR (14) not null UNIQUE
	CONSTRAINT CH_Product_List_Number CHECK (regexp_like(Product_List_Number, '[0-9]{10}\\-[0-9]{2}')),
	Date_Time_Create_PL TIMESTAMP null DEFAULT(CURRENT_TIMESTAMP)
);

insert into Product_List (Product_List_Number)
values ('0000000001-21'),
('0000000002-21'),
('0000000003-21');

select Product_List_Number as "Номер товарной сметы", Date_Time_Create_PL as "Дата и время создания" from Product_List
order by Date_Time_Create_PL DESC;

CREATE TABLE Cancellation
(
	ID_Cancellation int not null auto_increment PRIMARY KEY,
	Cancellation_Number VARCHAR(17) not null UNIQUE
	CONSTRAINT CH_Cancellation_Number CHECK (regexp_like(Cancellation_Number, '[0-9]{10}\\-[0-9]{2}\\-ОП')),
	Date_Create_Cncll TIMESTAMP null DEFAULT(CURRENT_TIMESTAMP)
);

insert into Cancellation (Cancellation_Number)
values ('0000000001-21-ОП'),
('0000000004-21-ОП'),
('0000000002-21-ОП'),
('0000000003-21-ОП');

select Cancellation_Number as "Номер отмены приёма", Date_Create_Cncll as "Дата формирования" from Cancellation
order by Date_Create_Cncll DESC;

CREATE TABLE Manufacturer
(
	ID_Manufacturer int not null auto_increment PRIMARY KEY,
	Name_Manufacturer VARCHAR (50) not null UNIQUE,
	Country_ID INT not null REFERENCES country (ID_Country)
);

insert into Manufacturer (Name_Manufacturer, Country_ID)
values ('Nestle',1),
('1-ый овощь на р-не',2),
('Мясницкий ряд',2),
('Вимм-Биль-Дан',2);

select Name_Manufacturer as "Название производителя", Name_Country as "Страна поизводителя" from Manufacturer
inner join Country on Country_ID = ID_Country
order by Name_Country ASC, Name_Manufacturer DESC;

CREATE TABLE Warehouse
(
	ID_Warehouse int not null auto_increment PRIMARY KEY,
	Warehouse_Adress VARCHAR(400) not null UNIQUE,
	Market_Place_ID INT not null REFERENCES Market_Place (ID_Market_Place)
);

insert into Warehouse (Warehouse_Adress, Market_Place_ID)
values ('ул. Чертановская, д.6, стр. 3', 1),
('ул. Чертановская, д.6, стр. 1', 1),
('ул. Волжская, д.10, к.2', 2);

select Warehouse_Adress as "Адрес склада", Market_Address as "Адрес маказина" from Warehouse
inner join Market_Place on ID_Market_Place = Market_Place_ID
order by Warehouse_Adress, Market_Address ASC;

CREATE TABLE Suppler
(
	ID_Suppler int not null auto_increment PRIMARY KEY,
	Type_Suppler_ID INT not null REFERENCES Type_Suppler (ID_Type_Suppler),
	Full_Name_Suppler VARCHAR(400) not null,
	Short_Name_Suppler VARCHAR (40) not null,
	Legal_Address_Suppler VARCHAR(400) not null,
	Physical_Address_Suppler VARCHAR(400) not null,
	Suppler_E_Mail VARCHAR(400) not null CONSTRAINT CH_Suppler_E_Mail CHECK
	(Suppler_E_Mail like '%@%.%'),
	Suppler_Phone_Number VARCHAR (18) not null UNIQUE
	CONSTRAINT CH_Suppler_Phone_Number 
	CHECK (regexp_like(Suppler_Phone_Number, '\\+7\\([0-9]{3}\\)[0-9]{3}\\-[0-9]{2}\\-[0-9]{2}')),
	BIC VARCHAR (9) not null CONSTRAINT CH_BIC CHECK (regexp_like(BIC,'[0-9]{8}')),
	ITN VARCHAR (13) not null UNIQUE 
	CONSTRAINT CH_ITN CHECK (regexp_like(ITN, '[0-9]{12}')),
	ARCoEaO VARCHAR (11) not null UNIQUE
	CONSTRAINT CH_ARCoEaO CHECK (regexp_like(ARCoEaO, '[0-9]{10}'))
);

insert into Suppler (Type_Suppler_ID, Full_Name_Suppler, Short_Name_Suppler, 
Legal_Address_Suppler, Physical_Address_Suppler, Suppler_E_Mail, Suppler_Phone_Number,
BIC, ITN, ARCoEaO)
values (1, '"Первый поставщик"', '"П Пост"', 'г. Москва, 155367, ул. Волоколамская, д.6, стр. 5', 
'г. Москва, 155367, ул. Волоколамская, д.6, стр. 5', '1postavschik@gmail.com', '+7(495)422-63-64', 
'35674316', '396652867052', '4824096316'),
(2, '"Куда скажете туда и поедем"', '"КСТиП"', 'г. Москва, 156733, ул. Бибирево, д.17, к.6,', 
'г. Москва, 173274, ул. Алтуфьево, д.47, стр.17', 'kuda_tuda@gmail.com', '+7(499)526-88-18', 
'29665123', '583349957123', '4995123385'),
(3, '"Быстро и надёжно"', '"БиН"', 'г. Санкт-Петербург, 4226432, ул. Новаторов, д.64, к.4',
'г. Москва, 198887, ул. Киевская, д.10, стр. 10', 'bin@gmail.com', '+7(999)542-77-87',
'83128904', '679333078641', '6722450097');

select Concat('Тип фирмы: ',Name_Suppler,', полное название: ',Full_Name_Suppler,', сокращённое название: ',Short_Name_Suppler) as "Данные о постащике",
Concat('Юридический адрес: ',Legal_Address_Suppler,', фактическтй адрес: ',Physical_Address_Suppler,'. Адрес электронной почты: ',Suppler_E_Mail,', контактный телефон: ',Suppler_Phone_Number) as "Контактная информация",
Concat('БИК: ',BIC,', ИНН: ',ITN,', ОКПО: ',ARCoEaO) as "Реквизиты фирмы поставщика" from Suppler
inner join  Type_Suppler on Type_Suppler_ID = ID_Type_Suppler
order by Name_Suppler DESC, Full_Name_Suppler ASC;

CREATE TABLE Representative
(
	ID_Representative int not null auto_increment PRIMARY KEY,
	Suppler_ID INT NOT NULL REFERENCES Suppler (ID_Suppler),
	First_Name_Repres VARCHAR (30) not null,
	Second_Name_Repres VARCHAR (30) not null,
	Middle_Name_Repres VARCHAR (30) null DEFAULT '-'
);

insert into Representative (Suppler_ID, First_Name_Repres, Second_Name_Repres, Middle_Name_Repres)
values (1,'Романов','Роман','Романович'),
(2,'Кириллов','Кирилл','Кириллович'),
(3,'Владимиров','Владимир','Владимирович');

select Concat('Тип организации: ',Name_Suppler,', Полное название: ',Full_Name_Suppler) as "Представляемая фирма", 
Concat(First_Name_Repres,' ',Second_Name_Repres,' ',Middle_Name_Repres) as "ФИО представителя" from Representative
inner join Suppler on Suppler_ID = ID_Suppler
inner join  Type_Suppler on Type_Suppler_ID = ID_Type_Suppler
order by Name_Suppler DESC,  First_Name_Repres ASC;

CREATE TABLE Treaty
(
	ID_Treaty int not null auto_increment PRIMARY KEY,
	Treaty_Number VARCHAR(16) not null UNIQUE
	CONSTRAINT CH_Treaty_Number 
	CHECK (regexp_like(Treaty_Number, '[0-9]{10}\\-[0-9]{2}\\-Д')),
	Urgent VARCHAR (3) not null CONSTRAINT CH_Urgent CHECK
	(Urgent in ('Да','Нет')),
	Term VARCHAR (16) not null CONSTRAINT CH_Term CHECK
	(regexp_like(Term, '[0-9]{2,3} лет|месяцев')),
	Date_Create_Term date null default(CURRENT_DATE),
	Representative_ID INT not null REFERENCES Representative (ID_Representative)
);	

insert into Treaty (Treaty_Number, Urgent, Term, Representative_ID)
values ('0000000001-21-Д','Да','05 лет',1),
('0000000002-21-Д','Да','05 лет',2),
('0000000003-21-Д','Да','02 лет',3);

select Treaty_Number as "Номер договора",  Concat('Срочный: ',Urgent,'. Срок действия: ',Term,'. Дата создания договора: ',Date_Create_Term) as "Детали договора",
Concat('Тип организации: ',Name_Suppler,', Полное название: ',Full_Name_Suppler,'. ФИО представителя:',First_Name_Repres,' ',Second_Name_Repres,' ',Middle_Name_Repres) as "Данные организации поставщика" 
from Treaty
inner join Representative on Representative_ID = ID_Representative
inner join Suppler on Suppler_ID = ID_Suppler
inner join  Type_Suppler on Type_Suppler_ID = ID_Type_Suppler
order by Date_Create_Term DESC, Name_Suppler ASC;

CREATE TABLE Buyer_Card
(
	ID_Buyer_Card int not null auto_increment PRIMARY KEY,
	Card_Number VARCHAR (20) not null UNIQUE
	CONSTRAINT CH_Card_Number CHECK (regexp_like(Card_Number, '[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}')),
	Card_Holder VARCHAR (60) not null,
	Validity VARCHAR (6) not null CONSTRAINT CH_Validity CHECK
	(regexp_like(Validity, '[0-9]{2}\\/[0-9]{2}')),
	Buyer_ID INT not null REFERENCES Buyer (ID_Buyer)
);

insert into Buyer_Card (Card_Number, Card_Holder, Validity, Buyer_ID)
values ('2245 5367 7642 7640','IVANOV IVAN','02/24',1),
('5542 5674 9974 8974','PETROV PETR','10/25',2),
('8444 8854 1178 9942','ANDREEV ANDREY','12/24',3);

select Concat(First_Name_Buyer,' ',Second_Name_Buyer,' ',Middle_Name_Buyer) as "Данные покупателя", 
Concat('Номер карты: ',Card_Number,'. Держатель: ',Card_Holder,', действительна до: ',Validity) as "Данные карты" from Buyer
inner join Buyer_Card on ID_Buyer = Buyer_ID
order by First_Name_Buyer ASC;

CREATE TABLE Combination
(
	ID_Combination int not null auto_increment PRIMARY KEY,
	Post_ID INT not null REFERENCES Post (ID_Post),
	Employee_ID INT not null REFERENCES Employee (ID_Employee)
);

insert into Combination (Post_ID, Employee_ID)
values (1,1),
(2,2),
(1,3);

select Concat(First_Name_Emp,' ',Second_Name_Emp,' ',Middle_Name_Emp) as "ФИО Сотрудника", Key_Employee as "Ключ отмены", Name_Post as "Должность" from Combination
inner join Employee on ID_Employee = Employee_ID
inner join Post on ID_Post = Post_ID
order by Name_Post ASC, First_Name_Emp DESC;

CREATE TABLE Employee_Change
(
	ID_Employee_Change int not null auto_increment PRIMARY KEY,
	Employee_Change_Number VARCHAR (12) not null UNIQUE
	CONSTRAINT CH_Employee_Change_Number CHECK (regexp_like(Employee_Change_Number, '[0-9]{11}')),
	Combination_ID INT not null REFERENCES Combination (ID_Combination),
	Cash_Machine_ID INT not null REFERENCES Cash_Machine (ID_Cash_Machine),
	Date_Time_Create_Emp_Chg TIMESTAMP null DEFAULT(CURRENT_TIMESTAMP)
);

insert into Employee_Change (Employee_Change_Number,Combination_ID,Cash_Machine_ID)
values ('00000000001', 1, 1),
('00000000002', 2, 2),
('00000000004', 3, 3),
('00000000005', 2, 2),
('00000000003', 1, 1);

select Concat('ФИО: ',First_Name_Emp,' ',Second_Name_Emp,' ',Middle_Name_Emp,', должность: ',Name_Post) as "Данные сотрудника", 
Concat('№ смены: ',Employee_Change_Number,', дата открытия: ',Date_Time_Create_Emp_Chg) as "Данные смены" from 
Employee_Change 
inner join Combination on Combination_ID = ID_Combination
inner join Employee on ID_Employee = Employee_ID
inner join Post on ID_Post = Post_ID
order by Employee_Change_Number DESC;

CREATE TABLE Product
(
	ID_Product int not null auto_increment PRIMARY KEY,
	Price_Product DECIMAL(38,2) null DEFAULT 0.0 CONSTRAINT CH_Price_Product
	CHECK (Price_Product >= 0.0),
	Product_Name VARCHAR (50) not null,
	Compound VARCHAR(400) not null,
	End_Date VARCHAR (20) not null,
	Vendor_Code VARCHAR (14) not null UNIQUE
	CONSTRAINT CH_Vendor_Code CHECK (regexp_like(Vendor_Code, '[A-Z][0-9]{6}\\-[0-9]{5}')),
	Type_Product_ID INT not null REFERENCES Type_Product (ID_Type_Product),
	Manufacturer_ID INT not null REFERENCES Manufacturer (ID_Manufacturer)
);

insert into Product (Price_Product, Product_Name, Compound, End_Date, 
Vendor_Code, Type_Product_ID, Manufacturer_ID)
values (340,'Кофе','Кофейные зёрна','72 месяца','F753273-76336',1,1),
(150,'Помидоры','Натуральные вещества','10 дней','R452677-43467',2,2),
(250,'Карбонат','Говядина','14 дней','Y762004-22787',3,3),
(120,'Растительное масло','Взбитое молоко 90%','6 месяцев','U632206-25453',4,4),
(110,'Молоко 5%','Натуральные вещества','12 дней','L653573-54373',4,4);

select Concat('Производитель: ',Name_Manufacturer,', страна: ',Name_Country) as "Данные производителя", Vendor_Code as "Артикул",
Concat('Название продукта: ',Product_Name,', цена за шт.: ',Price_Product,' руб., вид продукта: ',Name_Type,', описание - "',Compound,'", срок годности = ',End_Date) as "Данные товара"
from Product
inner join Type_Product on Type_Product_ID = ID_Type_Product
inner join Manufacturer on ID_Manufacturer = Manufacturer_ID
inner join Country on ID_Country = Country_ID
order by Price_Product ASC;

CREATE TABLE Product_List_View
(
	ID_Product_List_View int not null auto_increment PRIMARY KEY,
	Product_List_ID INT not null REFERENCES Product_List (ID_Product_List),
	Product_ID INT not null REFERENCES Product (ID_Product)
);

insert into Product_List_View (Product_List_ID, Product_ID)
values (1,1),
(2,2),
(1,3),
(1,4),
(3,5);

select Concat('Название: ',Product_Name,', артикурл: ',Vendor_Code,', вид товара: ',Name_Type) as "Данные товара", 
Concat('Номер сметы: ',Product_List_Number,'. Дата создания - ',Date_Time_Create_PL) as "Данные товарной сметы" from Product_List_View
inner join Product on ID_Product = Product_ID
inner join Type_Product on Type_Product_ID = ID_Type_Product
inner join Product_List on ID_Product_List = Product_List_ID
order by Date_Time_Create_PL DESC, Vendor_Code ASC;

CREATE TABLE Cancellation_View
(
	ID_Cancellation_View int not null auto_increment PRIMARY KEY,
	Cancellation_ID INT not null REFERENCES Cancellation (ID_Cancellation),
	Product_ID INT not null REFERENCES Product (ID_Product)
);

insert into Cancellation_View (Cancellation_ID, Product_ID)
values (1,1),
(4,2),
(2,3),
(1,4),
(3,5);

select Concat('Артикул: ',Vendor_Code,'. Название - ',Product_Name,', срок годности: ',End_Date,'. Стоимость: ',Price_Product,' руб.') as "Данные о товаре", 
Concat('Производитель: ',Name_Manufacturer,'. Страна: ',Name_Country) as "Данные производителя", Name_Type as "Тип товара", 
Concat('Номер отмены: ',Cancellation_Number,'. Дата формирования: ',Date_Create_Cncll) as "Данные отмены приёма"
from Cancellation_View
inner join Product on Product_ID = ID_Product
inner join Type_Product on ID_Type_Product = Type_Product_ID
inner join Manufacturer on ID_Manufacturer = Manufacturer_ID
inner join Country on ID_Country = Country_ID
inner join Cancellation on Cancellation_ID = ID_Cancellation
order by Date_Create_Cncll DESC, Vendor_Code ASC;

CREATE TABLE Supply
(
	ID_Supply int not null auto_increment PRIMARY KEY,
	Integrity_Supply VARCHAR (30) not null CONSTRAINT CH_Integrity_Supply
	CHECK (Integrity_Supply in ('Нормально','Нарушенное')),
	Supply_Number VARCHAR (16) not null UNIQUE
	CONSTRAINT CH_Supply_Number CHECK (regexp_like(Supply_Number, '[0-9]{10}\\-[0-9]{2}\\-П')),
	Date_Create_Supply DATE null DEFAULT (CURRENT_DATE),
	Time_Create_Supply TIME null DEFAULT (CURRENT_TIME),
	Treaty_ID INT not null REFERENCES Treaty (ID_Treaty),
	Warehouse_ID INT not null REFERENCES Warehouse (ID_Warehouse)
);

insert into Supply (Integrity_Supply, Supply_Number, Treaty_ID, Warehouse_ID)
values ('Нормально','0000000001-21-П',1,1),
('Нормально','0000000004-21-П',2,2),
('Нормально','0000000002-21-П',1,1),
('Нормально','0000000003-21-П',3,2);

select Concat('Номер поставки: ',Supply_Number,'. Целостнось: ',Integrity_Supply,'. Дата и время поставци: ',Date_Create_Supply
,' - ',Time_Create_Supply) as "Данные попоставке",
Concat('Адрес склада: ',Warehouse_Adress,'. Адрес магазина: ',Market_Address) as "Место доставки", 
Concat('Номем: ',Treaty_Number,'. Поставщик: ',Full_Name_Suppler) as "Данные договора" from Supply
inner join Treaty on Treaty_ID = ID_Treaty
inner join Representative on ID_Representative = Representative_ID
inner join Suppler on ID_Suppler = Suppler_ID
inner join Warehouse on ID_Warehouse = Treaty_ID
inner join Market_Place on ID_Market_Place = Market_Place_ID
order by Date_Create_Supply DESC, Time_Create_Supply ASC,  Treaty_Number ASC;

CREATE TABLE Supply_View
(
	ID_Supply_View int not null auto_increment PRIMARY KEY,
	Supply_Ammount INT not null CONSTRAINT CH_Supply_Ammount CHECK
	(Supply_Ammount > 0),
	Supply_ID INT not null REFERENCES Supply (ID_Supply),
	Product_ID INT not null REFERENCES Product (ID_Product)
);

insert into Supply_View (Supply_Ammount, Supply_ID, Product_ID)
values (1000, 1, 1),
(1200, 4, 2),
(900, 2, 3),
(2100, 1, 4),
(1750, 3, 5);

select Concat('Номер поставки: ',Supply_Number,'. Дата и время: ',Date_Create_Supply,' - ',Time_Create_Supply) as "Общие данные поставки", 
Concat('Склад: ',Warehouse_Adress,', торговая точка: ',Market_Address) as "Пункт доставки", 
Concat('Название продукта: ',Product_Name,', артикул = ',Vendor_Code,', количество в поставке: ',Supply_Ammount) as "Состав доставки" from Supply_View
inner join Product on ID_Product = Product_ID
inner join Supply on Supply_ID = ID_Supply
inner join Warehouse on Warehouse_ID = ID_Warehouse
inner join Market_Place on Market_Place_ID = ID_Market_Place
order by Date_Create_Supply DESC, Time_Create_Supply DESC, Supply_Ammount DESC;

CREATE TABLE Sale_Check
(
	ID_Sale_Check int not null auto_increment PRIMARY KEY,
	Sale_Check_Number VARCHAR (14) not null UNIQUE
	CONSTRAINT CH_Sale_Check_Number CHECK (regexp_like(Sale_Check_Number, '[0-9]{10}\\-ФК')),
	Date_Create_Check DATE null DEFAULT (Current_date),
	Time_Create_Check TIME null DEFAULT (Current_Time),
	Deposited_Ammount DECIMAL (38,2) not null CONSTRAINT CH_Deposited_Ammount
	CHECK (Deposited_Ammount > 0),
	Whith_VAT DECIMAL (38,2) not null CONSTRAINT CH_Whith_VAT 
	CHECK (Whith_VAT > 0),
	Without_VAT DECIMAL (38,2) not null CONSTRAINT CH_Without_VAT
	CHECK (Without_VAT >0),
	Payment_Type_ID INT not null REFERENCES Payment_Type (ID_Payment_Type),
	Employee_Change_ID INT not null REFERENCES Employee_Change (ID_Employee_Change),
	Buyer_Card_ID INT not null REFERENCES Buyer_Card (ID_Buyer_Card)
);

insert into Sale_Check (Sale_Check_Number, Deposited_Ammount, Whith_VAT, 
Without_VAT, Payment_Type_ID, Employee_Change_ID, Buyer_Card_ID)
values ('0000000001-ФК', 900, 804.00, 670.00, 1, 1, 1),
('0000000002-ФК', 900, 900.00, 750.00, 2, 2, 2),
('0000000004-ФК', 600, 600.00, 500.00, 1, 4, 3),
('0000000003-ФК', 144, 144.00, 120.00, 1, 3, 2);

select Concat('Номер чека -- ',Sale_Check_Number,'. Дата и время открытия: ',Date_Create_Check,' ',Time_Create_Check) as "Данные чека", 
Concat('Внесённая сумма: ',Deposited_Ammount,' руб. С НДС: ',Whith_VAT,' руб. Без НДС:',Without_VAT,' руб.') as "Оплата", 
Concat('ФИО острудника: ',First_Name_Emp,' ',Second_Name_Emp,' ',Middle_Name_Emp,'. Должность: ',Name_Post) as "Данные сотрудника",
Name_Payment_Type as "Тип оплаты" from Sale_Check
inner join Buyer_Card on Buyer_Card_ID = ID_Buyer_Card
inner join Employee_Change on ID_Employee_Change = Employee_Change_ID 
inner join Combination on ID_Combination = Combination_ID
inner join Cash_Machine on ID_Cash_Machine = Cash_Machine_ID
inner join Employee on ID_Employee = Employee_ID
inner join Post on ID_Post = Post_ID
inner join Payment_Type on ID_Payment_Type = Payment_Type_ID
order by Sale_Check_Number desc, Date_Create_Check DESC, Time_Create_Check ASC;

CREATE TABLE Sale_Check_View
(
	ID_Sale_Check_View int not null auto_increment PRIMARY KEY,
	Sale_Check_View_Ammount INT not null CONSTRAINT CH_Sale_Check_View_Ammount
	CHECK (Sale_Check_View_Ammount >0),
	Sale_Check_ID INT not null REFERENCES Sale_Check (ID_Sale_Check),
	Product_ID INT not null REFERENCES Product (ID_Product)
);

insert into Sale_Check_View (Sale_Check_View_Ammount, Sale_Check_ID, Product_ID)
values (1, 1, 1),
(5, 2, 2),
(2, 3, 3),
(1, 4, 4),
(3, 1, 5);

select Concat('Номер чека -- ',Sale_Check_Number,'. Дата и время открытия: ',Date_Create_Check,' ',Time_Create_Check) as "Данные чека", 
Concat('Название -- ',Product_Name,'; Цена за шт: -- ',Price_Product,' руб. Артикул = ',Vendor_Code
,'; Кол - во ',Sale_Check_View_Ammount) as "Товар чека"
from Sale_Check_View
inner join Sale_Check on Sale_Check_ID = ID_Sale_Check
inner join Product on ID_Product = Product_ID
order by Sale_Check_Number DESC, Date_Create_Check DESC;

update Type_Product set
	Name_Type = 'Овощная продукция'
		where
		ID_Type_Product = 2;
select * from Type_Product;
		
delete from Type_Product
	where ID_Type_Product = 3;
	
update Post set
	Name_Post = 'Главный продавец'
		where 
		ID_Post = 2;
select * from Post;
		
delete from Post
	where
	ID_Post = 1;

update Representative set
	Second_Name_Repres = 'Андрей'
	where
		ID_Representative = 2;
select * from Representative;

delete from Representative
	where 
	ID_Representative = 1;
	
update Buyer_Card set
	Card_Holder = 'PETROV PAVEL',
	Validity = '11/25'
		where
		ID_Buyer_Card = 2;
select * from Buyer_Card;

delete from Buyer_Card
	where
	ID_Buyer_Card = 1;

update Sale_Check_View set
	Product_ID = 4,
	Sale_Check_ID = 4
	where
		ID_Sale_Check_View = 5;
select * from Sale_Check_View;
		
delete from Sale_Check_View
	where
	ID_Sale_Check_View = 4;
select * from Sale_Check_View;

select Card_Number, Card_Holder from Buyer_Card 
where Validity like '%24';

select Concat(First_Name_Emp,' ',Second_Name_Emp,' ',Middle_Name_Emp) as "ФИО Сотрудника", Key_Employee as "Ключ отмены", Name_Post as "Должность" from Combination
inner join Employee on ID_Employee = Employee_ID
inner join Post on ID_Post = Post_ID
where Post_ID in (2,3);

select Concat('Производитель: ',Name_Manufacturer,', страна: ',Name_Country) as "Данные производителя", Vendor_Code as "Артикул",
Concat('Название продукта: ',Product_Name,', цена за шт.: ',Price_Product,' руб., вид продукта: ',Name_Type,', описание - "',Compound,'", срок годности = ',End_Date) as "Данные товара"
from Product
inner join Type_Product on Type_Product_ID = ID_Type_Product
inner join Manufacturer on ID_Manufacturer = Manufacturer_ID
inner join Country on ID_Country = Country_ID
where Name_Type = 'Мясное изделье';

SELECT  count(*) FROM information_schema.tables 
where table_schema = 'sale_product_database' and table_type = 'BASE TABLE';

SELECT  table_name, count(column_Name) FROM information_schema.columns
where table_schema = 'sale_product_database'
group by table_name;