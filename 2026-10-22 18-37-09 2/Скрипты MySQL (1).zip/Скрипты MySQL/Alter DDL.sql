use sale_product_database;

create table Test_Name
(
	ID_Key_Field int not null auto_increment primary key,
	Text_Fielld varchar (40) not null,
	Number_Field int null
);

Alter table Test_Name rename to Test_Name_1;

Alter table Test_Name_1 rename column Text_Fielld to Text_Field;

Alter table Test_Name_1 modify Number_Field Decimal(38,2);

Alter table Test_Name_1 add column Date_field date not null;

Alter table Test_Name_1 add constraint CH_Number_Field check (Number_Field >0);

Alter table Test_Name_1 drop constraint CH_Number_Field;

Alter table Test_Name_1 alter column Number_Field set default (0);

Alter table Test_Name_1 alter column Number_Field drop default;

Alter table Test_Name_1 modify Number_Field Decimal(38,2) not null;

Alter table Test_Name_1 modify Number_Field Decimal(38,2) null;

Alter table Test_Name_1 drop column Date_field;

Drop table Test_Name_1;