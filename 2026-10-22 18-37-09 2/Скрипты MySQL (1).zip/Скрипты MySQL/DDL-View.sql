use sale_product_database;

create or replace view Products_Market_Place_List
as
	select Product_Name as "Название товара", Compound as "Состав", End_Date "Срок годности", concat(Name_Country,' - ',Name_Manufacturer) as "Страна и фирма производителя", Price_Product as "Стоимость", 
    sum(Supply_Ammount)-sum(Sale_Check_View_Ammount) as "Доступное колличество", Market_Address as "Адрес магазина" from Product
	inner join Manufacturer on Manufacturer_ID = ID_Manufacturer
	inner join Country on Country_ID = ID_Country
	inner join Supply_View on ID_Product = Supply_View.Product_ID
	inner join Supply on Supply_ID = ID_Supply
	inner join Warehouse on Warehouse_ID = ID_Warehouse
	inner join Market_Place on Market_Place_ID = ID_Market_Place
	inner join Sale_Check_View on ID_Product = Sale_Check_View.Product_ID
	group by Product_Name, Compound, End_Date, concat(Name_Country,' - ',Name_Manufacturer), Price_Product, Market_Address
	having sum(Supply_Ammount)-sum(Sale_Check_View_Ammount) > 0;

select * from Products_Market_Place_List;

create or replace view Product_Buy_List
as
	select distinct(concat(Supply_Number,' ',Date_Create_Supply,' ',Time_Create_Supply)) as "Данные поставки", Market_Address as "Адрес торговой точки",
    group_concat(concat(Product_Name,' цена за шт. ',Price_Product,' руб. Артикул: ',Vendor_Code)) as "Состав поставки" from Product
	inner join Supply_View on ID_Product = Product_ID
	inner join Supply on Supply_ID = ID_Supply
	inner join Warehouse on Warehouse_ID = ID_Warehouse
	inner join Market_Place on Market_Place_ID = ID_Market_Place
	group by concat(Supply_Number,' ',Date_Create_Supply,' ',Time_Create_Supply), Market_Address;
	
select * from Product_Buy_List;

create or replace view Supplyer_Treaty
as
	select concat('Полное название: ',Full_Name_Suppler,', сокращённое название: ',Short_Name_Suppler) as "Основная информация", concat('Юр. Адрес: ',Physical_Address_Suppler,', Физ. адрес: ',Physical_Address_Suppler,', Телефон: '
	,Suppler_Phone_Number,', Адрес эл-ной почты: ',Suppler_E_Mail) as "Контактные данные",
	concat('БИК: ',BIC,', ИНН: ',ITN,', ОКПО: ',ARCoEaO) as "Реквизиты", Urgent as "Срочный", group_concat(concat(Product_Name,' ',Vendor_Code)) as "Поставляемый товар" from Product
	inner join Supply_View on ID_Product = Product_ID
	inner join Supply on Supply_ID = ID_Supply
	inner join Treaty on Treaty_ID = ID_Treaty
	inner join Representative on Representative_ID = ID_Representative
	inner join Suppler on Suppler_ID = ID_Suppler
	group by concat('Полное название: ',Full_Name_Suppler,', сокращённое название: ',Short_Name_Suppler), concat('Юр. Адрес: ',Physical_Address_Suppler,', Физ. адрес: ',Physical_Address_Suppler,', Телефон: '
	,Suppler_Phone_Number,', Адрес эл-ной почты: ',Suppler_E_Mail),
	concat('БИК: ',BIC,', ИНН: ',ITN,', ОКПО: ',ARCoEaO), Urgent;

select * from Supplyer_Treaty;

create or replace view Products_Remove_List
as
	select Warehouse_Adress as "Адрес склада", concat(Vendor_Code,' - ',Product_Name) as "Артикул и название продукции" from Warehouse
	inner join Supply on ID_Warehouse = Warehouse_ID
	inner join Supply_View on ID_Supply = Supply_ID
	inner join Product on ID_Product = Product_ID;

select * from Products_Remove_List;

create or replace view New_Buyer_Sale_List
as
	select concat(Card_Number,': Holder - ',Card_Holder,', срок годности: ',Validity) as "Банковская карта", concat(Sale_Check_Number,', дата создания: ',
	Date_Create_Check,', время создания: ',Time_Create_Check) as "Данные чека",
	concat(First_Name_Emp,' ',substring(Second_Name_Emp,1,1),'.',SUBSTRING(Middle_Name_Emp,1,1),'. ',Name_Post) as "Данные кассира" from Employee
	inner join Combination on ID_Employee = Employee_ID
	inner join Post on Post_ID = ID_Post
	inner join Employee_Change on ID_Combination = Combination_ID
	inner join Sale_Check on Employee_Change_ID = ID_Employee_Change
	inner join Buyer_Card on Buyer_Card_ID = ID_Buyer_Card
	inner join Payment_Type on Payment_Type_ID = ID_Payment_Type
	inner join Sale_Check_View on Sale_Check_ID = ID_Sale_Check
	inner join Product on Product_ID = ID_Product;

select * from New_Buyer_Sale_List;

create or replace view Finished_Sale_Check_List
as 
	select concat('Внесённая сумма: ',Deposited_Ammount,' руб., с НДС: ',Whith_VAT,' руб., без НДС: ',Without_VAT,'  руб.') as "Инфоромация об оплате",
	concat('Тип платежа: ',Name_Payment_Type,', № карты: ',Card_Number) as "Информация по карте", Employee_Change_Number as "Информация по смене" from Employee_Change
	inner join Sale_Check on ID_Employee_Change = Employee_Change_ID
	inner join Buyer_Card on ID_Buyer_Card = Buyer_Card_ID
	inner join Payment_Type on Payment_Type_ID = ID_Payment_Type;

select * from Finished_Sale_Check_List;

SELECT  count(*) FROM information_schema.tables 
where table_schema = 'sale_product_database' and table_type = 'VIEW';