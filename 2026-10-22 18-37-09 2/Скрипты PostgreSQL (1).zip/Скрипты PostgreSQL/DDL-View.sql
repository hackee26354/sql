create or replace view Products_Market_Place_List ("Название товара", "Состав", "Срок годности", "Страна и фирма производителя", "Стоимость", "Доступное колличество", "Адрес магазина")
as
	select Product_Name, Compound, End_Date, Name_Country||' - '||Name_Manufacturer, Price_Product, sum(Supply_Ammount)-sum(Sale_Check_View_Ammount), Market_Address from Product
	inner join Manufacturer on Manufacturer_ID = ID_Manufacturer
	inner join Country on Country_ID = ID_Country
	inner join Supply_View on ID_Product = Supply_View.Product_ID
	inner join Supply on Supply_ID = ID_Supply
	inner join Warehouse on Warehouse_ID = ID_Warehouse
	inner join Market_Place on Market_Place_ID = ID_Market_Place
	inner join Sale_Check_View on ID_Product = Sale_Check_View.Product_ID
	group by Product_Name, Compound, End_Date, Name_Country||' - '||Name_Manufacturer, Price_Product, Market_Address
	having sum(Supply_Ammount)-sum(Sale_Check_View_Ammount) > 0;

select * from Products_Market_Place_List;

create or replace view Product_Buy_List ("Данные поставки", "Адрес торговой точки", "Состав поставки")
as
	select distinct(Supply_Number||' '||Date_Create_Supply||' '||Time_Create_Supply), Market_Address ,string_agg(Product_Name||' цена за шт. '||Price_Product||' руб. Артикул: '||Vendor_Code, ', ') from Product
	inner join Supply_View on ID_Product = Product_ID
	inner join Supply on Supply_ID = ID_Supply
	inner join Warehouse on Warehouse_ID = ID_Warehouse
	inner join Market_Place on Market_Place_ID = ID_Market_Place
	group by Supply_Number||' '||Date_Create_Supply||' '||Time_Create_Supply, Market_Address;
	
select * from Product_Buy_List;

create or replace view Supplyer_Treaty ("Основная информация", "Контактные данные", "Реквизиты", "Срочный", "Поставляемый товар")
as
	select 'Полное название: '||Full_Name_Suppler||', сокращённое название: '||Short_Name_Suppler, 'Юр. Адрес: '||Physical_Address_Suppler||', Физ. адрес: '||Physical_Address_Suppler||', Телефон: '
	||Suppler_Phone_Number||', Адрес эл-ной почты: '||Suppler_E_Mail,
	'БИК: '||BIC||', ИНН: '||ITN||', ОКПО: '||ARCoEaO, Urgent, STRING_AGG(Product_Name||' '||Vendor_Code, ', ') from Product
	inner join Supply_View on ID_Product = Product_ID
	inner join Supply on Supply_ID = ID_Supply
	inner join Treaty on Treaty_ID = ID_Treaty
	inner join Representative on Representative_ID = ID_Representative
	inner join Suppler on Suppler_ID = ID_Suppler
	group by 'Полное название: '||Full_Name_Suppler||', сокращённое название: '||Short_Name_Suppler, 'Юр. Адрес: '||Physical_Address_Suppler||', Физ. адрес: '||Physical_Address_Suppler||', Телефон: '
	||Suppler_Phone_Number||', Адрес эл-ной почты: '||Suppler_E_Mail,
	'БИК: '||BIC||', ИНН: '||ITN||', ОКПО: '||ARCoEaO, Urgent;

select * from Supplyer_Treaty;

create or replace view Products_Remove_List ("Адрес склада", "Артикул и название продукции")
as
	select Warehouse_Adress,Vendor_Code||' - '||Product_Name from Warehouse
	inner join Supply on ID_Warehouse = Warehouse_ID
	inner join Supply_View on ID_Supply = Supply_ID
	inner join Product on ID_Product = Product_ID;

select * from Products_Remove_List;

create or replace view New_Buyer_Sale_List ("Банковская карта", "Данные чека", "Данные кассира")
as
	select Card_Number||': Holder - '||Card_Holder||', срок годности: '||Validity, Sale_Check_Number||', дата создания: '||
	Date_Create_Check||', время создания: '||Time_Create_Check,
	First_Name_Emp||' '||substring(Second_Name_Emp from 1 for 1)||'.'||SUBSTRING(Middle_Name_Emp from 1 for 1)||'. '||Name_Post from Employee
	inner join Combination on ID_Employee = Employee_ID
	inner join Post on Post_ID = ID_Post
	inner join Employee_Change on ID_Combination = Combination_ID
	inner join Sale_Check on Employee_Change_ID = ID_Employee_Change
	inner join Buyer_Card on Buyer_Card_ID = ID_Buyer_Card
	inner join Payment_Type on Payment_Type_ID = ID_Payment_Type
	inner join Sale_Check_View on Sale_Check_ID = ID_Sale_Check
	inner join Product on Product_ID = ID_Product;

select * from New_Buyer_Sale_List;

create or replace view Finished_Sale_Check_List ("Инфоромация об оплате", "Информация по карте","Информация по смене")
as 
	select 'Внесённая сумма: '||Deposited_Ammount||' руб., с НДС: '||Whith_VAT||' руб., без НДС: '||Without_VAT||'  руб.',
	'Тип платежа: '||Name_Payment_Type||', № карты: '||Card_Number, Employee_Change_Number from Employee_Change
	inner join Sale_Check on ID_Employee_Change = Employee_Change_ID
	inner join Buyer_Card on ID_Buyer_Card = Buyer_Card_ID
	inner join Payment_Type on Payment_Type_ID = ID_Payment_Type;


select * from Finished_Sale_Check_List;

SELECT count(*) FROM information_schema.tables 
where table_schema = 'public' and table_type = 'VIEW';