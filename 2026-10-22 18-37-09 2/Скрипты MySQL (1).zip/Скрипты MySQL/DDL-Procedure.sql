use sale_product_database;

DELIMITER //
create procedure Type_Product_insert (in p_Name_Type varchar (50))
begin
	insert into Type_Product (Name_Type)
	values (p_Name_Type);
end;
DELIMITER /

DELIMITER //
create procedure Type_Product_update (in p_ID_Type_Product int, in p_Name_Type varchar (50))
begin
    update Type_Product set
			Name_Type = p_Name_Type
				where
					ID_Type_Product = p_ID_Type_Product;
end;
DELIMITER /

DELIMITER //
create procedure Type_Product_delete (in p_ID_Type_Product int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Product
	where Type_Product_ID = p_ID_Type_Product;
    if (p_any_child_record > 0) then
			select'Тип продукта не может удалён, так как в таблице "Продукт", есть связанные данные!';
		else
			delete from Type_Product
				where
				ID_Type_Product = p_ID_Type_Product;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Country_insert (in p_Name_Country varchar (50))
begin
	insert into Country (Name_Country)
	values (p_Name_Country);
end;
DELIMITER /

DELIMITER //
create procedure Country_update (in p_ID_Country int, in p_Name_Country varchar (50))
begin
	update Country set
			Name_Country = p_Name_Country
			where
				ID_Country = p_ID_Country;
end;
DELIMITER /

DELIMITER //
create procedure Country_delete (in p_ID_Country int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Manufacturer
	where Country_ID = p_ID_Country;
    if (p_any_child_record > 0 ) then
			select 'Страна не может быть удалена, так как в таблице "Производитель", есть связанные данные!"';
		else
			delete from Country
			where
				ID_Country = p_ID_Country;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Market_Place_insert (in p_Market_Address varchar (400))
begin
	declare p_exsist_record int;
    select count(*) into p_exsist_record from Market_Place 
	where Market_Address = p_Market_Address;
    if (p_exsist_record > 0) then
			select  'Данная торговая точка уже есть в таблице!';
		else
			insert into Market_Place (Market_Address)
			values (p_Market_Address);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Market_Place_update (in p_ID_Market_Place int, in p_Market_Address varchar (400))
begin
	declare p_exsist_record int;
    select count(*) into p_exsist_record from Market_Place
	where Market_Address = p_Market_Address;
    if (p_exsist_record > 0) then
			select 'Данная торговая точка уже есть в таблице!';
		else
			update Market_Place set
				Market_Address = p_Market_Address
					where
						ID_Market_Place = p_ID_Market_Place;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Market_Place_delete (in p_ID_Market_Place int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Warehouse
	where Market_Place_ID = p_ID_Market_Place;
    if (p_any_child_record > 0 ) then
			select 'Торговая точка не может быть удалена, так как в таблице "Склад", есть связанные данные!"';
		else
			delete from Market_Place 
				where
					ID_Market_Place = p_ID_Market_Place;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Type_Suppler_insert (in p_Name_Suppler varchar (30))
begin
	insert into Type_Suppler (Name_Suppler)
	values (p_Name_Suppler);
end;
DELIMITER /

DELIMITER //
create procedure Type_Suppler_update (in p_ID_Type_Suppler int, in p_Name_Suppler varchar (30))
begin
	update Type_Suppler set
			Name_Suppler = p_Name_Suppler
				where
					ID_Type_Suppler = p_ID_Type_Suppler;
end;
DELIMITER /

DELIMITER //
create procedure Type_Suppler_delete (in p_ID_Type_Suppler int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Suppler
	where Type_Suppler_ID = p_ID_Type_Suppler;
    if (p_any_child_record > 0 ) then
			select 'Тип поставщика не может быть удален, так как в таблице "Поставщик", есть связанные данные!"';
		else
			delete from Type_Suppler 
				where
					ID_Type_Suppler = p_ID_Type_Suppler;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Payment_Type_insert (in p_Name_Payment_Type varchar (30))
begin
	insert into Payment_Type (Name_Payment_Type)
	values (p_Name_Payment_Type);
end;
DELIMITER /

DELIMITER //
create procedure Payment_Type_update (in p_ID_Payment_Type int, in p_Name_Payment_Type varchar (30))
begin
	update Payment_Type set
			Name_Payment_Type = p_Name_Payment_Type
				where
					ID_Payment_Type = p_ID_Payment_Type;
end;
DELIMITER /

DELIMITER //
create procedure Payment_Type_delete (in p_ID_Payment_Type int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Sale_Check
	where Payment_Type_ID = p_ID_Payment_Type;
    if (p_any_child_record > 0 ) then
			select 'Тип оплаты не может быть удален, так как в таблице "Товарный чек", есть связанные данные!"';
		else
			delete from Payment_Type 
				where
					ID_Payment_Type = p_ID_Payment_Type;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Post_insert (in p_Name_Post varchar (50))
begin
	insert into Post (Name_Post)
	values (p_Name_Post);
end;
DELIMITER /

DELIMITER //
create procedure Post_update (in p_ID_Post int, in p_Name_Post varchar (50))
begin
	update Post set
			Name_Post = p_Name_Post
				where
					ID_Post = p_ID_Post;
end;	
DELIMITER /

DELIMITER //
create procedure Post_delete (in p_ID_Post int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Combination
	where Post_ID = p_ID_Post;
    if (p_any_child_record > 0 ) then
			select 'Должность не может быть удалена, так как в таблице "Совместительство", есть связанные данные!"';
		else
			delete from Post
				where
					ID_Post = p_ID_Post;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Employee_insert (in p_First_Name_Emp varchar (30), in p_Second_Name_Emp varchar (30), in p_Middle_Name_Emp varchar (30),
in p_Key_Employee varchar (10), in p_Login_Employee varchar (32), in p_Password_Employee varchar (32))
begin
	declare p_exsit_buyer int;
    declare p_exist_employee int;
    declare p_New_key varchar (10);
    select count(*) into p_exsit_buyer from Buyer where 
	Login_Buyer = p_Login_Employee;
    if (p_exsit_buyer > 0) then
			select 'Пользователь с указанным логином, уже есть в системе!';
		else
			select count(*) into p_exist_employee from Employee 
			where First_Name_Emp = p_First_Name_Emp and Second_Name_Emp = p_Second_Name_Emp and 
			Middle_Name_Emp = p_Middle_Name_Emp and Login_Employee = p_Login_Employee;
				if (p_exist_employee > 0) then
					select 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					set p_New_key = '';
						if (p_Key_Employee <> '') or (p_Key_Employee is not null) then
				 			set p_New_key = p_Key_Employee;
						else
				 			set p_New_key = '-';
						end if;
						if (p_Middle_Name_Emp = null) then
							insert into Employee (First_Name_Emp, Second_Name_Emp,Key_Employee, Login_Employee, Password_Employee)
							values (p_First_Name_Emp, p_Second_Name_Emp, p_New_key, p_Login_Employee, p_Password_Employee);
						else
							insert into Employee (First_Name_Emp, Second_Name_Emp, Middle_Name_Emp, Key_Employee, Login_Employee, Password_Employee)
							values (p_First_Name_Emp, p_Second_Name_Emp, p_Middle_Name_Emp, p_Key_Employee, p_Login_Employee, p_Password_Employee);
						end if;
			end if;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Employee_update (in p_ID_Employee int, in p_First_Name_Emp varchar (30), in p_Second_Name_Emp varchar (30), in p_Middle_Name_Emp varchar (30),
in p_Key_Employee varchar (10), in p_Login_Employee varchar (32), in p_Password_Employee varchar (32))
begin
	declare p_exsit_buyer int;
    declare p_exist_employee int;
	declare p_New_key varchar (10);
    select count(*) into p_exsit_buyer from Buyer where 
	Login_Buyer = p_Login_Employee;
    if (p_exsit_buyer > 0) then
			select 'Пользователь с указанным логином, уже есть в системе!';
		else
			select count(*) into p_exist_employee from Employee 
			where First_Name_Emp = p_First_Name_Emp and Second_Name_Emp = p_Second_Name_Emp and 
			Middle_Name_Emp = p_Middle_Name_Emp and Login_Employee = p_Login_Employee;
				if (p_exist_employee > 0) then
					select 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					set p_New_key = '';
						if (p_Key_Employee <> '') or (p_Key_Employee is not null) then
				 			set p_New_key = p_Key_Employee;
						else
				 			set p_New_key = '-';
						end if;
						if (p_Middle_Name_Emp = null) then
							update Employee set
								First_Name_Emp = p_First_Name_Emp,
								Second_Name_Emp = p_Second_Name_Emp,
								Key_Employee = p_New_key,
								Login_Employee = p_Login_Employee,
								Password_Employee = p_Password_Employee
									where
										ID_Employee = p_ID_Employee;
						else
							update Employee set
								First_Name_Emp = p_First_Name_Emp,
								Second_Name_Emp = p_Second_Name_Emp,
								Middle_Name_Emp = p_Middle_Name_Emp,
								Key_Employee = p_New_key,
								Login_Employee = p_Login_Employee,
								Password_Employee =p_Password_Employee
									where
										ID_Employee = p_ID_Employee;
						end if;
			end if;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Employee_delete (in p_ID_Employee int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Combination
	where Employee_ID = p_ID_Employee;
    if (p_any_child_record > 0 ) then
			select 'Сотрудник не может быть удален, так как в таблице "Совместительство", есть связанные данные!"';
		else
			delete from Employee
				where
					ID_Employee = p_ID_Employee;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Cash_Machine_insert (in p_Cash_Machine_Number varchar (11))
begin
	declare p_New_Number varchar (8);
	declare p_Part_Number varchar (8);
	declare p_step int;
    if (p_Cash_Machine_Number = 'KA-________') or (p_Cash_Machine_Number = 'KA-') or (p_Cash_Machine_Number = ' ') then
		set p_New_Number = '';
		select count(*)+1 into p_Part_Number from Cash_Machine;
		set p_step = 8 - length(p_Part_Number);
		while p_step>0 do
			set p_step = p_step - 1;
            set p_New_Number = concat(p_New_Number,'0');
		end while;
		insert into Cash_Machine (Cash_Machine_Number)
		values (concat('КА-',p_New_Number,p_Part_Number));
	else
		insert into Cash_Machine (Cash_Machine_Number)
		values (p_Cash_Machine_Number);
	end if;
end;
DELIMITER /

DELIMITER //
create procedure Cash_Machine_update (in p_ID_Cash_Machine int, in p_Cash_Machine_Number varchar (11))
begin
	declare p_New_Number varchar (8);
	declare p_Part_Number varchar (8);
	declare p_step int;
    if (p_Cash_Machine_Number = 'KA-________') or (p_Cash_Machine_Number = 'KA-') or (p_Cash_Machine_Number = ' ') then
		set p_New_Number = '';
		select count(*)+1 into p_Part_Number from Cash_Machine;
		set p_step = 8 - length(p_Part_Number);
            while p_step>0 do
				set p_step = p_step - 1;
				set p_New_Number = concat(p_New_Number,'0');
			end while;
		update Cash_Machine set
				Cash_Machine_Number = concat('КА-',p_New_Number,p_Part_Number)
					where
						ID_Cash_Machine = p_ID_Cash_Machine;
	else
		update Cash_Machine set
				Cash_Machine_Number = p_Cash_Machine_Number
					where
						ID_Cash_Machine = p_ID_Cash_Machine;
	end if;
end;
DELIMITER /

DELIMITER //
create procedure Cash_Machine_delete (in p_ID_Cash_Machine int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Employee_Change
	where Cash_Machine_ID = p_ID_Cash_Machine;
    if (p_any_child_record > 0 ) then
			select 'Кассовый аппарат не может быть удален, так как в таблице "Смена сотрудника", есть связанные данные!"';
		else
			delete from Cash_Machine 
				where
					ID_Cash_Machine = p_ID_Cash_Machine;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Buyer_insert (in p_First_Name_Buyer varchar (30), in p_Second_Name_Buyer varchar (30), in p_Middle_Name_Buyer varchar (30), 
in p_Login_Buyer varchar (32), in p_Password_Buyer varchar (32))
begin
	declare p_excist_employee int;
    declare p_exist_buyer int;
	select count(*) into p_excist_employee from Employee
	where Login_Employee = p_Login_Buyer;
    if (p_excist_employee > 0) then
			select 'Пользователь с указанным логином, уже есть в системе!';
		else
			select count(*) into p_exist_buyer from Buyer
			where First_Name_Buyer = p_First_Name_Buyer and Second_Name_Buyer = p_Second_Name_Buyer  and 
			Middle_Name_Buyer =  p_Middle_Name_Buyer and Login_Buyer =  p_Login_Buyer;
				if (p_exist_buyer > 0) then
					select 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					if (p_Middle_Name_Buyer = null) then
						insert into Buyer (First_Name_Buyer, Second_Name_Buyer, Login_Buyer, Password_Buyer)
						values (p_First_Name_Buyer, p_Second_Name_Buyer, p_Login_Buyer, p_Password_Buyer);
					else
						insert into Buyer (First_Name_Buyer, Second_Name_Buyer, Middle_Name_Buyer, Login_Buyer, Password_Buyer)
						values (p_First_Name_Buyer, p_Second_Name_Buyer, p_Middle_Name_Buyer, p_Login_Buyer, p_Password_Buyer);
					end if;
				end if;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Buyer_update (in p_ID_Buyer int, in p_First_Name_Buyer varchar (30), in p_Second_Name_Buyer varchar (30), in p_Middle_Name_Buyer varchar (30), 
in p_Login_Buyer varchar (32), in p_Password_Buyer varchar (32))
begin
	declare p_excist_employee int;
    declare p_exist_buyer int;
	select count(*) into p_excist_employee from Employee
	where Login_Employee = p_Login_Buyer;
    if (p_excist_employee > 0) then
			select 'Пользователь с указанным логином, уже есть в системе!';
		else
			select count(*) into p_exist_buyer from Buyer
			where First_Name_Buyer = p_First_Name_Buyer and Second_Name_Buyer = p_Second_Name_Buyer  and 
			Middle_Name_Buyer =  p_Middle_Name_Buyer and Login_Buyer =  p_Login_Buyer;
				if (p_exist_buyer > 0) then
					select 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					if (p_Middle_Name_Buyer = null) then
						update Buyer set
							First_Name_Buyer = p_First_Name_Buyer,
							Second_Name_Buyer = p_Second_Name_Buyer,
							Login_Buyer = p_Login_Buyer,
							Password_Buyer = p_Password_Buyer
								where
									ID_Buyer = p_ID_Buyer;
					else
						update Buyer set
							First_Name_Buyer = p_First_Name_Buyer,
							Second_Name_Buyer = p_Second_Name_Buyer,
							Middle_Name_Buyer = p_Middle_Name_Buyer,
							Login_Buyer = p_Login_Buyer,
							Password_Buyer = p_Password_Buyer
								where
									ID_Buyer = p_ID_Buyer;
					end if;
				end if;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Buyer_delete (in p_ID_Buyer int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Buyer_Card
	where Buyer_ID = p_ID_Buyer;
		if (p_any_child_record > 0 ) then
			select 'Покупатель не может быть удален, так как в таблице "Банковская карта", есть связанные данные!"';
		else
			delete from Buyer
				where
					ID_Buyer = p_ID_Buyer;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_List_insert (in p_Product_List_Number varchar (13))
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
    if (p_Product_List_Number = '__________-__') or (p_Product_List_Number = ' ') then
		set p_new_Number = '';
		select count(*)+1 into p_Part_Number from Product_List;
		set p_step = 10 - length(p_Part_Number);
        while p_step>0 do
			set p_step = p_step -1;
            set p_new_Number = concat(p_new_Number,'0');
        end while;
        insert into Product_List (Product_List_Number)
		values (concat(p_new_Number,p_Part_Number,'-',substr(convert(current_date,char),3,2)));
        else
			insert into Product_List (Product_List_Number)
			values (p_Product_List_Number);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_List_update (in p_ID_Product_List int, in p_Product_List_Number varchar (13))
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
    if (p_Product_List_Number = '__________-__') or (p_Product_List_Number = ' ') then
		set p_new_Number = '';
		select count(*)+1 into p_Part_Number from Product_List;
		set p_step = 10 - length(p_Part_Number);
        while p_step>0 do
			set p_step = p_step -1;
            set p_new_Number = concat(p_new_Number,'0');
        end while;
			update Product_List set
				Product_List_Number = concat(p_new_Number,p_Part_Number,'-',substr(convert(current_date,char),3,2))
					where
						ID_Product_List = p_ID_Product_List;
        else
			update Product_List set
				Product_List_Number = p_Product_List_Number
					where
						ID_Product_List = p_ID_Product_List;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_List_delete (in p_ID_Product_List int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Product_List_View
	where Product_List_ID = p_ID_Product_List;
    if (p_any_child_record > 0 ) then
			select 'Смета не может быть удалена, так как в таблице "Состав сметы", есть связанные данные!"';
		else
			delete from Product_List 
				where
					ID_Product_List = p_ID_Product_List;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Cancellation_insert (in p_Cancellation_Number varchar (16))
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
    if (p_Cancellation_Number = '__________-__-__') or (p_Cancellation_Number = ' ') then
		set p_new_Number = '';
		select COUNT(*)+1 into p_Part_Number from Cancellation; 
		set p_step = 10 - length(p_Part_Number);
			while p_step>0 do
				set p_step = p_step - 1;
				set p_new_Number = concat(p_new_Number,'0');
			end while;
		insert into Cancellation (Cancellation_Number)
		values (concat(p_new_Number,p_Part_Number,'-',substr(convert(current_date,char),3,2),'-ОП'));
	else
		insert into Cancellation (Cancellation_Number)
		values (p_Cancellation_Number);
	end if;
end;
DELIMITER /

DELIMITER //
create procedure Cancellation_update (in p_ID_Cancellation int, in p_Cancellation_Number varchar (16))
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
    if (p_Cancellation_Number = '__________-__-__') or (p_Cancellation_Number = ' ') then
		set p_new_Number = '';
		select COUNT(*)+1 into p_Part_Number from Cancellation; 
		set p_step = 10 - length(p_Part_Number);
			while p_step>0 do
				set p_step = p_step - 1;
				set p_new_Number = concat(p_new_Number,'0');
			end while;
		update Cancellation set
				Cancellation_Number = concat(p_new_Number,p_Part_Number,'-',substr(convert(current_date,char),3,2),'-ОП')
					where
						ID_Cancellation = p_ID_Cancellation;
	else
		update Cancellation set
				Cancellation_Number = p_Cancellation_Number
					where
						ID_Cancellation = p_ID_Cancellation;
	end if;
end;
DELIMITER /
	
DELIMITER //
create procedure Cancellation_delete (in p_ID_Cancellation int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Cancellation_View
	where Cancellation_ID = p_ID_Cancellation;
    if (p_any_child_record > 0 ) then
			select 'Акт о возврате не может быть удален, так как в таблице "Состав акта возврата", есть связанные данные!"';
		else
			delete from Cancellation
				where
					ID_Cancellation = p_ID_Cancellation;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Manufacturer_insert (in p_Name_Manufacturer varchar (50), in p_Country_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Manufacturer
	where Name_Manufacturer = p_Name_Manufacturer and Country_ID = p_Country_ID;
    if (p_exist_record > 0) then
			select 'Указанный производитель уже есть у данной страны!';
		else
			insert into Manufacturer (Name_Manufacturer, Country_ID)
			values (p_Name_Manufacturer, p_Country_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Manufacturer_update (in p_ID_Manufacturer int, in p_Name_Manufacturer varchar (50), in p_Country_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Manufacturer
	where Name_Manufacturer = p_Name_Manufacturer and Country_ID = p_Country_ID;
    if (p_exist_record > 0) then
			select 'Указанный производитель уже есть у данной страны!';
		else
			update Manufacturer set
				Name_Manufacturer = p_Name_Manufacturer,
				Country_ID = p_Country_ID
					where
						ID_Manufacturer = p_ID_Manufacturer;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Manufacturer_delete (in p_ID_Manufacturer int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Product
	where Manufacturer_ID = p_ID_Manufacturer;
    if (p_any_child_record > 0 ) then
			select 'Производитель не может быть удален, так как в таблице "Продукт", есть связанные данные!"';
		else
			delete from Manufacturer 
				where
					ID_Manufacturer = p_ID_Manufacturer;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Warehouse_insert (in p_Warehouse_Adress varchar (400), in p_Market_Place_ID int)
begin
	declare p_exsist_record int;
    select count(*) into p_exsist_record from Warehouse 
	where Warehouse_Adress = p_Warehouse_Adress and Market_Place_ID = p_Market_Place_ID;
    if (p_exsist_record > 0) then
			select 'Данный склад у торговой точки уже есть в таблице!';
		else
			insert into Warehouse (Warehouse_Adress, Market_Place_ID)
			values (p_Warehouse_Adress, p_Market_Place_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Warehouse_update (in p_ID_Warehouse int, in p_Warehouse_Adress varchar (400), in p_Market_Place_ID int)
begin
	declare p_exsist_record int;
    select count(*) into p_exsist_record from Warehouse 
	where Warehouse_Adress = p_Warehouse_Adress and Market_Place_ID = p_Market_Place_ID;
    if (p_exsist_record > 0) then
			select 'Данный склад у торговой точки уже есть в таблице!';
		else
			update Warehouse set
				Warehouse_Adress = p_Warehouse_Adress,
				Market_Place_ID = p_Market_Place_ID
					where
						ID_Warehouse = p_ID_Warehouse;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Warehouse_delete (in p_ID_Warehouse int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Supply
	where Warehouse_ID = p_ID_Warehouse;
    if (p_any_child_record > 0 ) then
			select 'Склад не может быть удален, так как в таблице "Поставка", есть связанные данные!"';
		else
			delete from Warehouse
				where
					ID_Warehouse = p_ID_Warehouse;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Suppler_insert (in p_Type_Suppler_ID int, in p_Full_Name_Suppler varchar (400), in p_Short_Name_Suppler varchar (50), 
in p_Legal_Address_Suppler varchar (400), in p_Physical_Address_Suppler varchar (400), in p_Suppler_E_Mail varchar (400), 
in p_Suppler_Phone_Number varchar (17), in p_BIC varchar (8), in p_ITN varchar (12), in p_ARCoEaO varchar (10))
begin
	declare	p_exist_record int;
    select count(*) into p_exist_record from Suppler 
	where Type_Suppler_ID = p_Type_Suppler_ID and Full_Name_Suppler = p_Full_Name_Suppler and BIC = p_BIC 
	and Suppler_E_Mail = p_Suppler_E_Mail;
		if (p_exist_record > 0) then
			select 'Указанный тип организации, название, БИК и E-Mail уже есть в таблице!';
		else
			insert into Suppler (Type_Suppler_ID, Full_Name_Suppler, Short_Name_Suppler, Legal_Address_Suppler,Physical_Address_Suppler, Suppler_E_Mail, Suppler_Phone_Number, BIC, ITN, ARCoEaO)
			values (p_Type_Suppler_ID, p_Full_Name_Suppler, p_Short_Name_Suppler, p_Legal_Address_Suppler, p_Physical_Address_Suppler, p_Suppler_E_Mail, p_Suppler_Phone_Number, p_BIC, p_ITN, p_ARCoEaO);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Suppler_update (in p_ID_Suppler int, in p_Type_Suppler_ID int, in p_Full_Name_Suppler varchar (400), in p_Short_Name_Suppler varchar (50), 
in p_Legal_Address_Suppler varchar (400), in p_Physical_Address_Suppler varchar (400), in p_Suppler_E_Mail varchar (400), 
in p_Suppler_Phone_Number varchar (17), in p_BIC varchar (8), in p_ITN varchar (12), in p_ARCoEaO varchar (10))
begin
	declare	p_exist_record int;
    select count(*) into p_exist_record from Suppler 
	where Type_Suppler_ID = p_Type_Suppler_ID and Full_Name_Suppler = p_Full_Name_Suppler and BIC = p_BIC 
	and Suppler_E_Mail = p_Suppler_E_Mail;
		if (p_exist_record > 0) then
			select 'Указанный тип организации, название, БИК и E-Mail уже есть в таблице!';
		else
			update Suppler set
				Type_Suppler_ID = p_Type_Suppler_ID,
				Full_Name_Suppler = p_Full_Name_Suppler,
				Short_Name_Suppler = p_Short_Name_Suppler,
				Legal_Address_Suppler = p_Legal_Address_Suppler,
				Physical_Address_Suppler = p_Physical_Address_Suppler,
				Suppler_E_Mail = p_Suppler_E_Mail,
				Suppler_Phone_Number = p_Suppler_Phone_Number,
				BIC = p_BIC,
				ITN = p_ITN,
				ARCoEaO = p_ARCoEaO
					where
						ID_Suppler = p_ID_Suppler;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Suppler_delete (in p_ID_Suppler int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Representative
	where Suppler_ID = p_ID_Suppler;
    if (p_any_child_record > 0 ) then
			select 'Поставщик не может быть удален, так как в таблице "Представитель", есть связанные данные!"';
		else
			delete from Suppler 
				where
					ID_Suppler = p_ID_Suppler;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Representative_insert (in p_Suppler_ID int, in p_First_Name_Repres varchar (30), in p_Second_Name_Repres varchar (30),
in p_Middle_Name_Repres varchar (30))
begin
	declare p_exsit_record int;
    select count(*) into p_exsit_record from Representative
	where Suppler_ID = p_Suppler_ID and First_Name_Repres = p_First_Name_Repres and Second_Name_Repres = p_Second_Name_Repres and Middle_Name_Repres = p_Middle_Name_Repres;
    if (p_exsit_record > 0) then
				select 'В данный представитель уже есть в данной фирме!';
			else
				if (p_Middle_Name_Repres = '') or (p_Middle_Name_Repres = ' ') then
					insert into Representative (Suppler_ID, First_Name_Repres, Second_Name_Repres)
					values (p_Suppler_ID, p_First_Name_Repres, p_Second_Name_Repres);
				else
					insert into Representative (Suppler_ID, First_Name_Repres, Second_Name_Repres, Middle_Name_Repres)
					values (p_Suppler_ID, p_First_Name_Repres, p_Second_Name_Repres, p_Middle_Name_Repres);
				end if;
		end if;
end;
DELIMITER /
	
DELIMITER //
create procedure Representative_update (in p_ID_Representative int, in p_Suppler_ID int, in p_First_Name_Repres varchar (30), in p_Second_Name_Repres varchar (30),
in p_Middle_Name_Repres varchar (30))
begin
	declare p_exsit_record int;
    select count(*) into p_exsit_record from Representative
	where Suppler_ID = p_Suppler_ID and First_Name_Repres = p_First_Name_Repres and Second_Name_Repres = p_Second_Name_Repres and Middle_Name_Repres = p_Middle_Name_Repres;
		if (p_exsit_record > 0) then
			select 'В данный представитель уже есть в данной фирме!';
		else
			if (p_Middle_Name_Repres = '') or (p_Middle_Name_Repres = ' ') then
				update Representative set
					Suppler_ID = p_Suppler_ID,
					First_Name_Repres = p_First_Name_Repres,
					Second_Name_Repres = p_Second_Name_Repres
						where
							ID_Representative = p_ID_Representative;
			else  
				update Representative set
					Suppler_ID = p_Suppler_ID,
					First_Name_Repres = p_First_Name_Repres,
					Second_Name_Repres = p_Second_Name_Repres,
					Middle_Name_Repres = p_Middle_Name_Repres
						where
							ID_Representative = p_ID_Representative;
			end if;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Representative_delete (in p_ID_Representative int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Treaty
	where Representative_ID = p_ID_Representative;
    if (p_any_child_record > 0 ) then
			select 'Представитель не может быть удален, так как в таблице "Договор", есть связанные данные!"';
		else
			delete from Representative 
				where
					ID_Representative = p_ID_Representative;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Treaty_insert (in p_Treaty_Number varchar (15), in p_Urgent varchar (3), in p_Term varchar (15), in p_Representative_ID int)
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
    if (p_Treaty_Number = '__________-__-Д') or (p_Treaty_Number = ' ') then
			set p_new_Number = '';
			select count(*)+1 into p_Part_Number from Treaty;
			set p_step = 10 - length(p_Part_Number);
            while p_step>0 do
				set p_step = p_step-1;
                set p_new_Number = concat(p_new_Number,'0');
            end while;
			insert into Treaty (Treaty_Number, Urgent, Term, Representative_ID)
			values (concat(p_new_Number,p_Part_Number,'-',SUBSTR(convert(current_date,char),3,2),'-Д'), p_Urgent, p_Term, p_Representative_ID);
		else
			insert into Treaty (Treaty_Number, Urgent, Term, Representative_ID)
			values (p_Treaty_Number, p_Urgent, p_Term, p_Representative_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Treaty_update (in p_ID_Treaty int, in p_Treaty_Number varchar (15), in p_Urgent varchar (3), in p_Term varchar (15), in p_Representative_ID int)
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
    if (p_Treaty_Number = '__________-__-Д') or (p_Treaty_Number = ' ') then
			set p_new_Number = '';
			select count(*)+1 into p_Part_Number from Treaty;
			set p_step = 10 - length(p_Part_Number);
            while p_step>0 do
				set p_step = p_step-1;
                set p_new_Number = concat(p_new_Number,'0');
            end while;
            update Treaty set
				Treaty_Number = p_Treaty_Number,
				Urgent = p_Urgent,
				Term = p_Term,
				Representative_ID =concat(p_new_Number,p_Part_Number,'-',SUBSTR(convert(current_date,char),3,2),'-Д')
					where
						ID_Treaty = p_ID_Treaty;
		else
			update Treaty set
				Treaty_Number = p_Treaty_Number,
				Urgent = p_Urgent,
				Term = p_Term,
				Representative_ID =p_Representative_ID
					where
						ID_Treaty = p_ID_Treaty;
		end if;
end;
DELIMITER /
	
DELIMITER //
create procedure Treaty_delete (in p_ID_Treaty int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Supply
	where Treaty_ID = p_ID_Treaty;
		if (p_any_child_record > 0 ) then
			select 'Договор не может быть удален, так как в таблице "Поставка", есть связанные данные!"';
		else
			delete from Treaty
				where
					ID_Treaty = p_ID_Treaty;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Buyer_Card_insert (in p_Card_Number varchar (19), in p_Card_Holder varchar (60), in p_Validity varchar (5),
in p_Buyer_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Buyer_Card
	where Card_Number = p_Card_Number and Buyer_ID = p_Buyer_ID;
		if (p_exist_record > 0) then
			select 'У данного клиента уже есть указанная банковская карта!';
		else
			insert into Buyer_Card (Card_Number, Card_Holder, Validity, Buyer_ID)
			values (p_Card_Number, p_Card_Holder, p_Validity, p_Buyer_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Buyer_Card_update (in p_ID_Buyer_Card int, in p_Card_Number varchar (19), in p_Card_Holder varchar (60), in p_Validity varchar (5),
in p_Buyer_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Buyer_Card
	where Card_Number = p_Card_Number and Buyer_ID = p_Buyer_ID;
		if (p_exist_record > 0) then
			select 'У данного клиента уже есть указанная банковская карта!';
		else
			update Buyer_Card set
				Card_Number = p_Card_Number,
				Card_Holder = p_Card_Holder,
				Validity = p_Validity,
				Buyer_ID = p_Buyer_ID
					where
						ID_Buyer_Card = p_ID_Buyer_Card;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Buyer_Card_delete (in p_ID_Buyer_Card int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Sale_Check
	where Buyer_Card_ID = p_ID_Buyer_Card;
		if (p_any_child_record > 0 ) then
			select 'Карта клиента не может быть удалена, так как в таблице "Товарный чек", есть связанные данные!"';
		else
			delete from Buyer_Card 
				where
					ID_Buyer_Card = p_ID_Buyer_Card;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Combination_insert (in p_Post_ID int, in p_Employee_ID int)
begin
	declare p_exist_rectord int;
    select count(*) into p_exist_rectord from  Combination 
	where Post_ID = p_Post_ID and Employee_ID = p_Employee_ID;
		if (p_exist_rectord > 0 ) then
			select 'Указанная должность уже имеется у сотрудника!';
		else
			insert into Combination (Post_ID, Employee_ID)
			values (p_Post_ID, p_Employee_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Combination_update (in p_ID_Combination int, in p_Post_ID int, in p_Employee_ID int)
begin
	declare p_exist_rectord int;
    select count(*) into p_exist_rectord from  Combination 
	where Post_ID = p_Post_ID and Employee_ID = p_Employee_ID;
		if (p_exist_rectord > 0 ) then
			select 'Указанная должность уже имеется у сотрудника!';
		else
			update Combination set
				Post_ID = p_Post_ID,
				Employee_ID = p_Employee_ID
					where
						ID_Combination = p_ID_Combination;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Combination_delete (in p_ID_Combination int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Employee_Change
	where Combination_ID = p_ID_Combination;
		if (p_any_child_record > 0 ) then
			select 'Совместительство не может быть удалено, так как в таблице "Смена сотрудника", есть связанные данные!"';
		else
			delete from Combination
				where
					ID_Combination = p_ID_Combination;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Employee_Change_insert (in p_Combination_ID int, in p_Cash_Machine_ID int)
begin
	declare p_new_Number varchar (11);
	declare p_Part_Number varchar (11);
	declare p_step int;
    set p_new_Number = '';
	select  count(*)+1 into p_Part_Number from Treaty;
	set p_step = 11 - length(p_Part_Number);
		while p_step>0 do
			set p_step = p_step-1;
			set p_new_Number = concat(p_new_Number,'0');
        end while;
	insert into Employee_Change (Employee_Change_Number, Combination_ID, Cash_Machine_ID)
	values (concat(p_new_Number,p_Part_Number), p_Combination_ID, p_Cash_Machine_ID);
end;
DELIMITER /

DELIMITER //
create procedure Employee_Change_delete (in p_ID_Employee_Change int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Sale_Check
	where Employee_Change_ID = p_ID_Employee_Change;
		if (p_any_child_record > 0 ) then
			select 'Смена не может быть удалена, так как в таблице "Товарный чек", есть связанные данные!"';
		else
			delete from Employee_Change 
				where
				ID_Employee_Change = p_ID_Employee_Change;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_insert (in p_Price_Product decimal (38,2), in p_Product_Name varchar (50), in p_Compound varchar (400),
in p_End_Date date, in p_Vendor_Code varchar (13), in p_Type_Product_ID int, in p_Manufacturer_ID int)
begin
	insert into Product (Price_Product, Product_Name, Compound, End_Date, Vendor_Code, Type_Product_ID, Manufacturer_ID)
	values (p_Price_Product, p_Product_Name, p_Compound, p_End_Date, p_Vendor_Code, p_Type_Product_ID, p_Manufacturer_ID);
end;

DELIMITER //
create procedure Product_update (in p_ID_Product int, in p_Price_Product decimal (38,2), in p_Product_Name varchar (50), in p_Compound varchar (400),
in p_End_Date date, in p_Vendor_Code varchar (13), in p_Type_Product_ID int, in p_Manufacturer_ID int)
begin
	update Product set
			Price_Product = p_Price_Product,
			Product_Name = p_Product_Name,
			Compound = p_Compound,
			End_Date = p_End_Date,
			Vendor_Code = p_Vendor_Code,
			Type_Product_ID = p_Type_Product_ID,
			Manufacturer_ID = p_Manufacturer_ID
				where
					ID_Product = p_ID_Product;
end;
DELIMITER /

DELIMITER //
create  procedure Product_delete (in p_ID_Product int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Product
	inner join Cancellation_View on ID_Product = Cancellation_View.Product_ID
	inner join Product_List_View on ID_Product = Product_List_View.Product_ID
	inner join Sale_Check_View on ID_Product = Sale_Check_View.Product_ID
	inner join Supply_View on ID_Product = Supply_View.Product_ID 
	where Cancellation_View.Product_ID = p_ID_Product or Product_List_View.Product_ID = p_ID_Product 
	or Sale_Check_View.Product_ID = p_ID_Product or Supply_View.Product_ID = p_ID_Product;
		if (p_any_child_record > 0 ) then
			select 'Продукт не может быть удален, так как в одной из таблиц: "Состав акта возврата", "Состав сметы", "Состав чека" или "Состав поставки", есть связанные данные!"';
		else
			delete from Product 
				where
					ID_Product = p_ID_Product;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_List_View_insert (in p_Product_List_ID int, in p_Product_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Product_List_View
	where Product_List_ID = p_Product_List_ID and Product_ID = p_Product_ID;
		if (p_exist_record > 0) then
			select 'Указанный товар уже есть в заявке!';
		else
			insert into Product_List_View (Product_List_ID, Product_ID)
			values (p_Product_List_ID, p_Product_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_List_View_update (in p_ID_Product_List_View int, in p_Product_List_ID int, in p_Product_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Product_List_View
	where Product_List_ID = p_Product_List_ID and Product_ID = p_Product_ID;
		if (p_exist_record > 0) then
			select 'Указанный товар уже есть в заявке!';
		else
			update Product_List_View set
				Product_List_ID = p_Product_List_ID,
				Product_ID = p_Product_ID
					where
						ID_Product_List_View = p_ID_Product_List_View ;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Product_List_View_delete (in p_ID_Product_List_View int)
begin
	delete from Product_List_View 
			where
				ID_Product_List_View = p_ID_Product_List_View;
end;
DELIMITER /

DELIMITER //
create procedure Cancellation_View_insert (in p_Cancellation_ID int, in p_Product_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Cancellation_View
	where Cancellation_ID = p_Cancellation_ID and Product_ID = p_Product_ID;
    if (p_exist_record > 0) then
			select 'В указанном акте уже имеется данный товар!';
		else
			insert into Cancellation_View (Cancellation_ID, Product_ID)
			values (p_Cancellation_ID, p_Product_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Cancellation_View_update (in p_ID_Cancellation_View int, in p_Cancellation_ID int, in p_Product_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Cancellation_View
	where Cancellation_ID = p_Cancellation_ID and Product_ID = p_Product_ID;
    if (p_exist_record > 0) then
			select 'В указанном акте уже имеется данный товар!';
		else
			update Cancellation_View set
				Cancellation_ID = p_Cancellation_ID,
				Product_ID = p_Product_ID
					where
						ID_Cancellation_View = p_ID_Cancellation_View;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Cancellation_View_delete (in p_ID_Cancellation_View int)
begin
	delete from Cancellation_View 
			where
				ID_Cancellation_View = p_ID_Cancellation_View;
end;
DELIMITER /

DELIMITER //
create procedure Supply_insert (in p_Integrity_Supply varchar (30), in p_Supply_Number varchar (15), in p_Treaty_ID int, in p_Warehouse_ID int)
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
		if (p_Supply_Number = '__________-__-_') or (p_Supply_Number = ' ') then
			set p_new_Number = '';
			select count(*)+1 into p_Part_Number from Supply;
			set p_step = 10 - length(p_Part_Number);
            while p_step>0 do
				set p_step = p_step-1;
                set p_new_Number = concat(p_new_Number,0);
            end while;
			insert into Supply (Integrity_Supply, Supply_Number, Treaty_ID, Warehouse_ID)
			values (p_Integrity_Supply, concat(p_new_Number,p_Part_Number,'-',SUBSTR(convert(current_date,char),3,2),'-П'), p_Treaty_ID, p_Warehouse_ID);
		else
			insert into Supply (Integrity_Supply, Supply_Number, Treaty_ID, Warehouse_ID)
			values (p_Integrity_Supply, p_Supply_Number, p_Treaty_ID, p_Warehouse_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Supply_update (in p_ID_Supply int, in p_Integrity_Supply varchar (30), in p_Supply_Number varchar (15), in p_Treaty_ID int, in p_Warehouse_ID int)
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
		if (p_Supply_Number = '__________-__-_') or (p_Supply_Number = ' ') then
			set p_new_Number = '';
			select count(*)+1 into p_Part_Number from Supply;
			set p_step = 10 - length(p_Part_Number);
            while p_step>0 do
				set p_step = p_step-1;
                set p_new_Number = concat(p_new_Number,0);
            end while;
			update Supply set
				Integrity_Supply = p_Integrity_Supply,
				Supply_Number = concat(p_new_Number,p_Part_Number,'-',SUBSTR(convert(current_date,char),3,2),'-П'),
				Treaty_ID = p_Treaty_ID,
				Warehouse_ID = p_Warehouse_ID
					where
						ID_Supply = p_ID_Supply;
		else
			update Supply set
				Integrity_Supply = p_Integrity_Supply,
				Supply_Number = p_Supply_Number,
				Treaty_ID = p_Treaty_ID,
				Warehouse_ID = p_Warehouse_ID
					where
						ID_Supply = p_ID_Supply;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Supply_delete (in p_ID_Supply int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Supply_View
	where Supply_ID = p_ID_Supply;
    if (p_any_child_record > 0 ) then
			select 'Поставка не может быть удалена, так как в таблице "Состав поставки", есть связанные данные!"';
		else
			delete from Supply
				where
					ID_Supply = p_ID_Supply;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Supply_View_insert (in p_Supply_Ammount int, in p_Supply_ID int, in p_Product_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Supply_View 
	where Supply_ID = p_Supply_ID and Product_ID = p_Product_ID and Supply_Ammount = p_Supply_Ammount;
    if (p_exist_record > 0) then
			select 'Указанный товар уже есть в смете!';
		else
			insert into Supply_View (Supply_Ammount, Supply_ID, Product_ID)
			values (p_Supply_Ammount, p_Supply_ID, p_Product_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Supply_View_update (in p_ID_Supply_View int, in p_Supply_Ammount int, in p_Supply_ID int, in p_Product_ID int)
begin
	declare p_exist_record int;
    select count(*) into p_exist_record from Supply_View 
	where Supply_ID = p_Supply_ID and Product_ID = p_Product_ID and Supply_Ammount = p_Supply_Ammount;
    if (p_exist_record > 0) then
			select 'Указанный товар уже есть в смете!';
		else
			update Supply_View set
				Supply_Ammount = p_Supply_Ammount,
				Supply_ID = p_Supply_ID,
				Product_ID = p_Product_ID
					where
						ID_Supply_View = p_ID_Supply_View;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Supply_View_delete (in p_ID_Supply_View int)
begin
	delete from Supply_View
			where
				ID_Supply_View = p_ID_Supply_View;
end;
DELIMITER /

DELIMITER //
create procedure Sale_Check_insert (in p_Sale_Check_Number varchar (14), in p_Deposited_Ammount decimal (38,2), in p_Whith_VAT decimal (38,2),
in p_Without_VAT decimal (38,2), in p_Payment_Type_ID int,
in p_Employee_Change_ID int, in p_Buyer_Card_ID int)
begin
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
		if (p_Sale_Check_Number = '_________-__') or (p_Sale_Check_Number = ' ') then
			set p_new_Number = '';
			select count(*)+1 into p_Part_Number from Sale_Check;
			set p_step = 10 - length(p_Part_Number);
				while p_step>0 do
					set p_new_Number = concat(p_new_Number,'0');
                    set p_step = p_step - 1;
				end while;
			insert into Sale_Check (Sale_Check_Number, Deposited_Ammount, Whith_VAT, Without_VAT, Payment_Type_ID, Employee_Change_ID, Buyer_Card_ID)
			values (concat(p_new_Number,p_Part_Number,'-ФК'), p_Deposited_Ammount, p_Whith_VAT, p_Without_VAT, p_Payment_Type_ID, p_Employee_Change_ID, p_Buyer_Card_ID);
		else
			insert into Sale_Check (Sale_Check_Number, Deposited_Ammount, Whith_VAT, Without_VAT, Payment_Type_ID, Employee_Change_ID, Buyer_Card_ID)
			values (p_Sale_Check_Number, p_Deposited_Ammount, p_Whith_VAT, p_Without_VAT, p_Payment_Type_ID, p_Employee_Change_ID, p_Buyer_Card_ID);
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Sale_Check_delete (in p_ID_Sale_Check int)
begin
	declare p_any_child_record int;
    select count(*) into p_any_child_record from Sale_Check_View
	where Sale_Check_ID = p_ID_Sale_Check;
		if (p_any_child_record > 0 ) then
			select 'Товарный чек не может быть удален, так как в таблице "Состав товарного чека", есть связанные данные!"';
		else
			delete from Sale_Check
				where
					ID_Sale_Check = p_ID_Sale_Check;
			end if;
end;
DELIMITER /

DELIMITER //
create procedure Sale_Check_View_Work (in p_Sale_Check_ID int, in p_Product_ID int)
begin
	declare p_ID_sale_check_view int;
    select ID_Sale_Check_View into p_ID_sale_check_view from Sale_Check_View
	where Sale_Check_ID = p_Sale_Check_ID and Product_ID = p_Product_ID;
    if (p_ID_sale_check_view is null) then
			insert into Sale_Check_View (Sale_Check_View_Ammount, Sale_Check_ID, Product_ID)
			values (1, p_Sale_Check_ID, p_Product_ID);
		else
			update Sale_Check_View set
				Sale_Check_View_Ammount = Sale_Check_View_Ammount + 1,
				Sale_Check_ID = p_Sale_Check_ID,
				Product_ID = p_Product_ID
					where
						ID_Sale_Check_View = p_ID_sale_check_view;
		end if;
end;
DELIMITER /

DELIMITER //
create procedure Sale_Check_View_delete (in p_ID_Sale_Check_View int)
begin
	delete from Sale_Check_View
			where
			ID_Sale_Check_View = p_ID_Sale_Check_View;
end;
DELIMITER /

call Type_Product_insert('Бытовая химия');
select * from Type_Product;

call Type_Product_update(5,'Химическая продукция');
select * from Type_Product;

call Type_Product_delete(5);
select * from Type_Product;

call Type_Product_delete(1);
select * from Type_Product;

call Type_Product_insert('Мясное изделье');
select * from Type_Product;

call Cash_Machine_insert(' ');
select * from Cash_Machine;

SELECT  count(*) FROM information_schema.routines 
where routine_schema = 'sale_product_database' and routine_type = 'PROCEDURE';