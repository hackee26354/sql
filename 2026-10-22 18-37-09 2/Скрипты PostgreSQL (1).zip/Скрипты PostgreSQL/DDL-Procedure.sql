create or replace procedure Type_Product_insert (p_Name_Type varchar (50))
language plpgsql
as $$
	begin
		insert into Type_Product (Name_Type)
		values (p_Name_Type);
		exception when others
		then
			raise notice 'Данный вид продукта уже есть в таблице!';
		end;
$$;

create or replace procedure Type_Product_update (p_ID_Type_Product int, p_Name_Type varchar (50))
language plpgsql
as $$
	begin
		update Type_Product set
			Name_Type = p_Name_Type
				where
					ID_Type_Product = p_ID_Type_Product;
		exception when others
		then
			raise notice'Данный вид продукта уже есть в таблице!';
		end;
$$;

create or replace procedure Type_Product_delete (p_ID_Type_Product int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Product
	where Type_Product_ID = p_ID_Type_Product;
	begin
		if (p_any_child_record > 0) then
			raise notice'Тип продукта не может удалён, так как в таблице "Продукт", есть связанные данные!';
		else
			delete from Type_Product
				where
				ID_Type_Product = p_ID_Type_Product;
		end if;
	end;
$$;

create or replace procedure Country_insert (p_Name_Country varchar (50))
language plpgsql
as $$
	begin
		insert into Country (Name_Country)
		values (p_Name_Country);
		exception when others
		then
			raise notice'Данная страна уже имеется в таблице!';
		end;
$$;

create or replace procedure Country_update (p_ID_Country int, p_Name_Country varchar (50))
language plpgsql
as $$
	begin
		update Country set
			Name_Country = p_Name_Country
			where
				ID_Country = p_ID_Country;
		exception when others
		then
			raise notice'Данная страна уже имеется в таблице!';
		end;	
$$;

create or replace procedure Country_delete (p_ID_Country int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Manufacturer
	where Country_ID = p_ID_Country;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Страна не может быть удалена, так как в таблице "Производитель", есть связанные данные!"';
		else
			delete from Country
			where
				ID_Country = p_ID_Country;
		end if;
	end;
$$;

create or replace procedure Market_Place_insert (p_Market_Address varchar)
language plpgsql
as $$
	declare p_exsist_record int := count(*) from Market_Place 
	where Market_Address = p_Market_Address;
	begin
		if (p_exsist_record > 0) then
			raise notice 'Данная торговая точка уже есть в таблице!';
		else
			insert into Market_Place (Market_Address)
			values (p_Market_Address);
		end if;
	end;
$$;

create or replace procedure Market_Place_update (p_ID_Market_Place int, p_Market_Address varchar)
language plpgsql
as $$
	declare p_exsist_record int := count(*) from Market_Place
	where Market_Address = p_Market_Address;
	begin
		if (p_exsist_record > 0) then
			raise notice 'Данная торговая точка уже есть в таблице!';
		else
			update Market_Place set
				Market_Address = p_Market_Address
					where
						ID_Market_Place = p_ID_Market_Place;
		end if;
	end;
$$;

create or replace procedure Market_Place_delete (p_ID_Market_Place int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Warehouse
	where Market_Place_ID = p_ID_Market_Place;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Торговая точка не может быть удалена, так как в таблице "Склад", есть связанные данные!"';
		else
			delete from Market_Place 
				where
					ID_Market_Place = p_ID_Market_Place;
		end if;
	end;
$$;

create or replace procedure Type_Supplier_insert (p_Name_Supplier varchar (30))
language plpgsql
as $$
	begin
		insert into Type_Supplier (Name_Supplier)
		values (p_Name_Supplier);
		exception when others
		then
			raise notice 'Данный тип поставщика уже есть в таблице!';
		end;	
$$;

create or replace procedure Type_Supplier_update (p_ID_Type_Supplier int, p_Name_Supplier varchar (30))
language plpgsql
as $$
	begin
		update Type_Supplier set
			Name_Supplier = p_Name_Supplier
				where
					ID_Type_Supplier = p_ID_Type_Supplier;
		exception when others
		then
			raise notice 'Данный тип поставщика уже есть в таблице!';
		end;	
$$;

create or replace procedure Type_Supplier_delete (p_ID_Type_Supplier int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Suppler
	where Type_Suppler_ID = p_ID_Type_Supplier;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Тип поставщика не может быть удален, так как в таблице "Поставщик", есть связанные данные!"';
		else
			delete from Type_Supplier 
				where
					ID_Type_Supplier = p_ID_Type_Supplier;
		end if;
	end;
$$;

create or replace procedure Payment_Type_insert (p_Name_Payment_Type varchar (30))
language plpgsql
as $$
	
	begin
		insert into Payment_Type (Name_Payment_Type)
		values (p_Name_Payment_Type);
		exception when others
		then
			raise notice 'Данный вид оплаты уже есть в таблице!';
		end;	
$$;

create or replace procedure Payment_Type_update (p_ID_Payment_Type int, p_Name_Payment_Type varchar (30))
language plpgsql
as $$
	
	begin
		update Payment_Type set
			Name_Payment_Type = p_Name_Payment_Type
				where
					ID_Payment_Type = p_ID_Payment_Type;
		exception when others
		then
			raise notice 'Данный вид оплаты уже есть в таблице!';
		end;	
$$;

create or replace procedure Payment_Type_delete (p_ID_Payment_Type int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Sale_Check
	where Payment_Type_ID = p_ID_Payment_Type;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Тип оплаты не может быть удален, так как в таблице "Товарный чек", есть связанные данные!"';
		else
			delete from Payment_Type 
				where
					ID_Payment_Type = p_ID_Payment_Type;
		end if;
	end;
$$;

create or replace procedure Post_insert (p_Name_Post varchar (50))
language plpgsql
as $$
	
	begin
		insert into Post (Name_Post)
		values (p_Name_Post);
		exception when others
		then
			raise notice 'Данное название должности уже есть в таблице!';
		end;	
$$;

create or replace procedure Post_update (p_ID_Post int, p_Name_Post varchar (50))
language plpgsql
as $$
	
	begin
		update Post set
			Name_Post = p_Name_Post
				where
					ID_Post = p_ID_Post;
		exception when others
		then
			raise notice 'Данное название должности уже есть в таблице!';
		end;	
$$;

create or replace procedure Post_delete (p_ID_Post int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Combination
	where Post_ID = p_ID_Post;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Должность не может быть удалена, так как в таблице "Совместительство", есть связанные данные!"';
		else
			delete from Post
				where
					ID_Post = p_ID_Post;
		end if;
	end;
$$;

create or replace procedure Employee_insert (p_First_Name_Emp varchar (30), p_Second_Name_Emp varchar (30), p_Middle_Name_Emp varchar (30),
p_Key_Employee varchar (10), p_Login_Employee varchar (32), p_Password_Employee varchar (32))
language plpgsql
as $$
	declare p_exsit_buyer int := count(*) from Buyer where 
	Login_Buyer = p_Login_Employee;
	declare p_exist_employee int;
	declare p_New_key varchar (10);
	begin
		if (p_exsit_buyer > 0) then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		else
			p_exist_employee := count(*) from Employee 
			where First_Name_Emp = p_First_Name_Emp and Second_Name_Emp = p_Second_Name_Emp and 
			Middle_Name_Emp = p_Middle_Name_Emp and Login_Employee = p_Login_Employee;
				if (p_exist_employee > 0) then
					raise notice 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					p_New_key := '';
						if (p_Key_Employee <> '') or (p_Key_Employee is not null) then
				 			p_New_key := p_Key_Employee;
						else
				 			p_New_key := '-';
						end if;
						if (p_Middle_Name_Emp = null) then
							insert into Employee (First_Name_Emp, Second_Name_Emp,Key_Employee, Login_Employee, Password_Employee)
							values (p_First_Name_Emp, p_Second_Name_Emp, p_New_key, p_Login_Employee, p_Password_Employee);
						else
							insert into Employee (First_Name_Emp, Second_Name_Emp, Middle_Name_Emp, Key_Employee, Login_Employee, Password_Employee)
							values (p_First_Name_Emp, p_Second_Name_Emp, p_Middle_Name_Emp, p_Key_Employee, p_Login_Employee, p_Password_Employee);
						end if;
			end if;
		end if;
		exception when others
		then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		end;	
$$;

create or replace procedure Employee_update (p_ID_Employee int, p_First_Name_Emp varchar (30), p_Second_Name_Emp varchar (30), p_Middle_Name_Emp varchar (30),
p_Key_Employee varchar (10), p_Login_Employee varchar (32), p_Password_Employee varchar (32))
language plpgsql
as $$
	declare p_exsit_buyer int := count(*) from Buyer where 
	Login_Buyer = p_Login_Employee;
	declare p_exist_employee int;
	declare p_New_key varchar (10);
	begin
		if (p_exsit_buyer > 0) then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		else
			p_exist_employee := count(*) from Employee 
			where First_Name_Emp = p_First_Name_Emp and Second_Name_Emp = p_Second_Name_Emp and 
			Middle_Name_Emp = p_Middle_Name_Emp and Login_Employee = p_Login_Employee;
				if (p_exist_employee > 0) then
					raise notice 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					p_New_key := '';
						if (p_Key_Employee <> '') or (p_Key_Employee is not null) then
				 			p_New_key := p_Key_Employee;
						else
				 			p_New_key := '-';
						end if;
						if (p_Middle_Name_Emp = null) then
							update Employee set
								First_Name_Emp = p_First_Name_Emp,
								Second_Name_Emp = p_Second_Name_Emp,
								Key_Employee = p_New_key,
								Login_Employee = p_Login_Employee,
								Password_Employee = p_Password_Employee
									where
										ID_Employee = p_ID_Employee;
						else
							update Employee set
								First_Name_Emp = p_First_Name_Emp,
								Second_Name_Emp = p_Second_Name_Emp,
								Middle_Name_Emp = p_Middle_Name_Emp,
								Key_Employee = p_New_key,
								Login_Employee = p_Login_Employee,
								Password_Employee =p_Password_Employee
									where
										ID_Employee = p_ID_Employee;
						end if;
			end if;
		end if;
		exception when others
		then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		end;		
$$;

create or replace procedure Employee_delete (p_ID_Employee int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Combination
	where Employee_ID = p_ID_Employee;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Сотрудник не может быть удален, так как в таблице "Совместительство", есть связанные данные!"';
		else
			delete from Employee
				where
					ID_Employee = p_ID_Employee;
		end if;
	end;
$$;

create or replace procedure Cash_Machine_insert (p_Cash_Machine_Number varchar (11))
language plpgsql
as $$
	declare p_New_Number varchar (8);
	declare p_Part_Number varchar (8);
	declare p_step int;
	begin
		if (p_Cash_Machine_Number = 'KA-________') or (p_Cash_Machine_Number = 'KA-') or (p_Cash_Machine_Number = ' ') then
			p_New_Number := '';
			p_Part_Number := count(*)+1 from Cash_Machine;
			p_step := 8 - length(p_Part_Number);
				for i in 1..p_step loop
					p_New_Number := p_New_Number||'0';		
				end loop;
			insert into Cash_Machine (Cash_Machine_Number)
			values ('КА-'||p_New_Number||p_Part_Number);
		else
			insert into Cash_Machine (Cash_Machine_Number)
			values (p_Cash_Machine_Number);
		end if;
		exception when others
		then
			raise notice 'Данный кассовый аппарат уже есть в таблице!';
		end;	
$$;

create or replace procedure Cash_Machine_update (p_ID_Cash_Machine int, p_Cash_Machine_Number varchar (11))
language plpgsql
as $$
declare p_New_Number varchar (8);
	declare p_Part_Number varchar (8);
	declare p_step int;
	begin
		if (p_Cash_Machine_Number = 'KA-________') or (p_Cash_Machine_Number = 'KA-') or (p_Cash_Machine_Number = ' ') then
			p_New_Number := '';
			p_Part_Number := count(*)+1 from Cash_Machine;
			p_step := 8 - length(p_Part_Number);
				for i in 1..p_step loop
					p_New_Number := p_New_Number||'0';		
				end loop;
			update Cash_Machine set
				Cash_Machine_Number = 'КА-'||p_New_Number||p_Part_Number
					where
						ID_Cash_Machine = p_ID_Cash_Machine;
		else
			update Cash_Machine set
				Cash_Machine_Number = p_Cash_Machine_Number
					where
						ID_Cash_Machine = p_ID_Cash_Machine;
		end if;
		exception when others
		then
			raise notice 'Данный кассовый аппарат уже есть в таблице!';
		end;	
$$;

create or replace procedure Cash_Machine_delete (p_ID_Cash_Machine int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Employee_Change
	where Cash_Machine_ID = p_ID_Cash_Machine;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Кассовый аппарат не может быть удален, так как в таблице "Смена сотрудника", есть связанные данные!"';
		else
			delete from Cash_Machine 
				where
					ID_Cash_Machine = p_ID_Cash_Machine;
		end if;
	end;
$$;

create or replace procedure Buyer_insert (p_First_Name_Buyer varchar (30), p_Second_Name_Buyer varchar (30), p_Middle_Name_Buyer varchar (30), 
p_Login_Buyer varchar (32), p_Password_Buyer varchar (32))
language plpgsql
as $$
	declare p_excist_employee int := count(*) from Employee
	where Login_Employee = p_Login_Buyer;
	declare p_exist_buyer int;
	begin
		if (p_excist_employee > 0) then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		else
			p_exist_buyer := count(*) from Buyer
			where First_Name_Buyer = p_First_Name_Buyer and Second_Name_Buyer = p_Second_Name_Buyer  and 
			Middle_Name_Buyer =  p_Middle_Name_Buyer and Login_Buyer =  p_Login_Buyer;
				if (p_exist_buyer > 0) then
					raise notice 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					if (p_Middle_Name_Buyer = null) then
						insert into Buyer (First_Name_Buyer, Second_Name_Buyer, Login_Buyer, Password_Buyer)
						values (p_First_Name_Buyer, p_Second_Name_Buyer, p_Login_Buyer, p_Password_Buyer);
					else
						insert into Buyer (First_Name_Buyer, Second_Name_Buyer, Middle_Name_Buyer, Login_Buyer, Password_Buyer)
						values (p_First_Name_Buyer, p_Second_Name_Buyer, p_Middle_Name_Buyer, p_Login_Buyer, p_Password_Buyer);
					end if;
				end if;
		end if;
		exception when others
		then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		end;	
$$;

create or replace procedure Buyer_update (p_ID_Buyer int, p_First_Name_Buyer varchar (30), p_Second_Name_Buyer varchar (30), p_Middle_Name_Buyer varchar (30), 
p_Login_Buyer varchar (32), p_Password_Buyer varchar (32))
language plpgsql
as $$
	declare p_excist_employee int := count(*) from Employee
	where Login_Employee = p_Login_Buyer;
	declare p_exist_buyer int;
	begin
		if (p_excist_employee > 0) then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		else
			p_exist_buyer := count(*) from Buyer
			where First_Name_Buyer = p_First_Name_Buyer and Second_Name_Buyer = p_Second_Name_Buyer  and 
			Middle_Name_Buyer =  p_Middle_Name_Buyer and Login_Buyer =  p_Login_Buyer;
				if (p_exist_buyer > 0) then
					raise notice 'Пользователь с указанными ФИО и логином, уже есть в системе!';
				else
					if (p_Middle_Name_Buyer = null) then
						update Buyer set
							First_Name_Buyer = p_First_Name_Buyer,
							Second_Name_Buyer = p_Second_Name_Buyer,
							Login_Buyer = p_Login_Buyer,
							Password_Buyer = p_Password_Buyer
								where
									ID_Buyer = p_ID_Buyer;
					else
						update Buyer set
							First_Name_Buyer = p_First_Name_Buyer,
							Second_Name_Buyer = p_Second_Name_Buyer,
							Middle_Name_Buyer = p_Middle_Name_Buyer,
							Login_Buyer = p_Login_Buyer,
							Password_Buyer = p_Password_Buyer
								where
									ID_Buyer = p_ID_Buyer;
					end if;
				end if;
		end if;
		exception when others
		then
			raise notice 'Пользователь с указанным логином, уже есть в системе!';
		end;	
$$;

create or replace procedure Buyer_delete (p_ID_Buyer int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Buyer_Card
	where Buyer_ID = p_ID_Buyer;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Покупатель не может быть удален, так как в таблице "Банковская карта", есть связанные данные!"';
		else
			delete from Buyer
				where
					ID_Buyer = p_ID_Buyer;
		end if;
	end;
$$;

create or replace procedure Product_List_insert (p_Product_List_Number varchar (13))
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Product_List_Number = '__________-__') or (p_Product_List_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Product_List;
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			insert into Product_List (Product_List_Number)
			values (p_new_Number||p_Part_Number||'-'||substring(current_date::varchar from 3 for 2));
		else
			insert into Product_List (Product_List_Number)
			values (p_Product_List_Number);
		end if;
		exception when others
		then
			raise notice 'Данный номер сметы уже есть в таблице!';
		end;	
$$;

create or replace procedure Product_List_update (p_ID_Product_List int, p_Product_List_Number varchar (13))
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Product_List_Number = '__________-__') or (p_Product_List_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Product_List;
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			update Product_List set
				Product_List_Number = p_new_Number||p_Part_Number||'-'||substring(current_date::varchar from 3 for 2)
					where
						ID_Product_List = p_ID_Product_List;
		else
			update Product_List set
				Product_List_Number = p_Product_List_Number
					where
						ID_Product_List = p_ID_Product_List;
		end if;
		exception when others
		then
			raise notice 'Данный номер сметы уже есть в таблице!';
		end;	
$$;

create or replace procedure Product_List_delete (p_ID_Product_List int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from p_Product_List_View
	where Product_List_ID = p_ID_Product_List;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Смета не может быть удалена, так как в таблице "Состав сметы", есть связанные данные!"';
		else
			delete from Product_List 
				where
					ID_Product_List = p_ID_Product_List;
		end if;
	end;
$$;

create or replace procedure Cancellation_insert (p_Cancellation_Number varchar (16))
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Cancellation_Number = '__________-__-__') or (p_Cancellation_Number = ' ') then
			p_new_Number := '';
			p_Part_Number :=  COUNT(*)+1 from Cancellation; 
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			insert into Cancellation (Cancellation_Number)
			values (p_new_Number||p_Part_Number||'-'||SUBSTRING(current_date::varchar from 3 for 2)||'-ОП');
		else
			insert into Cancellation (Cancellation_Number)
			values (p_Cancellation_Number);
		end if;
		exception when others
		then
			raise notice 'Данный номер акта отказа уже есть в таблице!';
		end;	
$$;

create or replace procedure Cancellation_update (p_ID_Cancellation int, p_Cancellation_Number varchar (16))
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Cancellation_Number = '__________-__-__') or (p_Cancellation_Number = ' ') then
			p_new_Number := '';
			p_Part_Number :=  COUNT(*)+1 from Cancellation; 
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			update Cancellation set
				Cancellation_Number = p_new_Number||p_Part_Number||'-'||SUBSTRING(current_date::varchar from 3 for 2)||'-ОП'
					where
						ID_Cancellation = p_ID_Cancellation;
		else
			update Cancellation set
				Cancellation_Number = p_Cancellation_Number
					where
						ID_Cancellation = p_ID_Cancellation;
		end if;
		exception when others
		then
			raise notice 'Данный номер акта отказа уже есть в таблице!';
		end;	
$$;

create or replace procedure Cancellation_delete (p_ID_Cancellation int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Cancellation_View
	where Cancellation_ID = p_ID_Cancellation;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Акт о возврате не может быть удален, так как в таблице "Состав акта возврата", есть связанные данные!"';
		else
			delete from Cancellation
				where
					ID_Cancellation = p_ID_Cancellation;
		end if;
	end;
$$;

create or replace procedure Manufacturer_insert (p_Name_Manufacturer varchar (50), p_Country_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Manufacturer
	where Name_Manufacturer = p_Name_Manufacturer and Country_ID = p_Country_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный производитель уже есть у данной страны!';
		else
			insert into Manufacturer (Name_Manufacturer, Country_ID)
			values (p_Name_Manufacturer, p_Country_ID);
		end if;
		exception when others
		then
			raise notice 'Указанный производитель уже есть в таблице!';
		end;	
$$;

create or replace procedure Manufacturer_update (p_ID_Manufacturer int, p_Name_Manufacturer varchar (50), p_Country_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Manufacturer
	where Name_Manufacturer = p_Name_Manufacturer and Country_ID = p_Country_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный производитель уже есть у данной страны!';
		else
			update Manufacturer set
				Name_Manufacturer = p_Name_Manufacturer,
				Country_ID = p_Country_ID
					where
						ID_Manufacturer = p_ID_Manufacturer;
		end if;
		exception when others
		then
			raise notice 'Указанный производитель уже есть в таблице!';
		end;	
$$;

create or replace procedure Manufacturer_delete (p_ID_Manufacturer int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Product
	where Manufacturer_ID = p_ID_Manufacturer;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Производитель не может быть удален, так как в таблице "Продукт", есть связанные данные!"';
		else
			delete from Manufacturer 
				where
					ID_Manufacturer = p_ID_Manufacturer;
		end if;
	end;
$$;

create or replace procedure Warehouse_insert (p_Warehouse_Adress varchar, p_Market_Place_ID int)
language plpgsql
as $$
	declare p_exsist_record int := count(*) from Warehouse 
	where Warehouse_Adress = p_Warehouse_Adress and Market_Place_ID = p_Market_Place_ID;
	begin
		if (p_exsist_record > 0) then
			raise notice 'Данный склад у торговой точки уже есть в таблице!';
		else
			insert into Warehouse (Warehouse_Adress, Market_Place_ID)
			values (p_Warehouse_Adress, p_Market_Place_ID);
		end if;
	end;
$$;
	
create or replace procedure Warehouse_update (p_ID_Warehouse int, p_Warehouse_Adress varchar, p_Market_Place_ID int)
language plpgsql
as $$
	declare p_exsist_record int := count(*) from Warehouse
	where Warehouse_Adress = p_Warehouse_Adress and Market_Place_ID = p_Market_Place_ID;
	begin
		if (p_exsist_record > 0) then
			raise notice 'Данный склад у торговой точки уже есть в таблице!';
		else
			update Warehouse set
				Warehouse_Adress = p_Warehouse_Adress,
				Market_Place_ID = p_Market_Place_ID
					where
						ID_Warehouse = p_ID_Warehouse;
		end if;
	end;
$$;

create or replace procedure Warehouse_delete (p_ID_Warehouse int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Supply
	where Warehouse_ID = p_ID_Warehouse;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Склад не может быть удален, так как в таблице "Поставка", есть связанные данные!"';
		else
			delete from Warehouse
				where
					ID_Warehouse = p_ID_Warehouse;
		end if;
	end;
$$;

create or replace procedure Suppler_insert (p_Type_Suppler_ID int, p_Full_Name_Suppler varchar, p_Short_Name_Suppler varchar (50), 
p_Legal_Address_Suppler varchar, p_Physical_Address_Suppler varchar, p_Suppler_E_Mail varchar, 
p_Suppler_Phone_Number varchar (17), p_BIC varchar (8), p_ITN varchar (12), p_ARCoEaO varchar (10))
language plpgsql
as $$
	declare	p_exist_record int := count(*) from Suppler 
	where Type_Suppler_ID = p_Type_Suppler_ID and Full_Name_Suppler = p_Full_Name_Suppler and BIC = p_BIC 
	and Suppler_E_Mail = p_Suppler_E_Mail;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный тип организации, название, БИК и E-Mail уже есть в таблице!';
		else
			insert into Suppler (Type_Suppler_ID, Full_Name_Suppler, Short_Name_Suppler, Legal_Address_Suppler,Physical_Address_Suppler, Suppler_E_Mail, Suppler_Phone_Number, BIC, ITN, ARCoEaO)
			values (p_Type_Suppler_ID, p_Full_Name_Suppler, p_Short_Name_Suppler, p_Legal_Address_Suppler, p_Physical_Address_Suppler, p_Suppler_E_Mail, p_Suppler_Phone_Number, p_BIC, p_ITN, p_ARCoEaO);
		end if;
	end;
$$;

create or replace procedure Suppler_update (p_ID_Suppler int, p_Type_Suppler_ID int, p_Full_Name_Suppler varchar, p_Short_Name_Suppler varchar (50), 
p_Legal_Address_Suppler varchar, p_Physical_Address_Suppler varchar, p_Suppler_E_Mail varchar, 
p_Suppler_Phone_Number varchar (17), p_BIC varchar (8), p_ITN varchar (12), p_ARCoEaO varchar (10))
language plpgsql
as $$
	declare	p_exist_record int := count(*) from Suppler 
	where Type_Suppler_ID = p_Type_Suppler_ID and Full_Name_Suppler = p_Full_Name_Suppler and BIC = p_BIC 
	and Suppler_E_Mail = p_Suppler_E_Mail;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный тип организации, название, БИК и E-Mail уже есть в таблице!';
		else
			update Suppler set
				Type_Suppler_ID = p_Type_Suppler_ID,
				Full_Name_Suppler = p_Full_Name_Suppler,
				Short_Name_Suppler = p_Short_Name_Suppler,
				Legal_Address_Suppler = p_Legal_Address_Suppler,
				Physical_Address_Suppler = p_Physical_Address_Suppler,
				Suppler_E_Mail = p_Suppler_E_Mail,
				Suppler_Phone_Number = p_Suppler_Phone_Number,
				BIC = p_BIC,
				ITN = p_ITN,
				ARCoEaO = p_ARCoEaO
					where
						ID_Suppler = p_ID_Suppler;
		end if;
	end;
$$;

create or replace procedure Suppler_delete (p_ID_Suppler int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Representative
	where Suppler_ID = p_ID_Suppler;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Поставщик не может быть удален, так как в таблице "Представитель", есть связанные данные!"';
		else
			delete from Suppler 
				where
					ID_Suppler = p_ID_Suppler;
		end if;
	end;
$$;

create or replace procedure Representative_insert (p_Suppler_ID int, p_First_Name_Repres varchar (30), p_Second_Name_Repres varchar (30),
p_Middle_Name_Repres varchar (30))
language plpgsql
as $$
	declare p_exsit_record int := count(*) from Representative
	where Suppler_ID = p_Suppler_ID and First_Name_Repres = p_First_Name_Repres and Second_Name_Repres = p_Second_Name_Repres and p_Middle_Name_Repres;
	begin
		if (p_exsit_record > 0) then
				raise notice 'В данный представитель уже есть в данной фирме!';
			else
				if (p_Middle_Name_Repres = '') or (p_Middle_Name_Repres = ' ') then
					insert into Representative (Suppler_ID, First_Name_Repres, Second_Name_Repres)
					values (p_Suppler_ID, p_First_Name_Repres, p_Second_Name_Repres);
				else
					insert into Representative (Suppler_ID, First_Name_Repres, Second_Name_Repres, Middle_Name_Repres)
					values (p_Suppler_ID, p_First_Name_Repres, p_Second_Name_Repres, p_Middle_Name_Repres);
				end if;
		end if;
	end;
$$;
	

create or replace procedure Representative_update (p_ID_Representative int, p_Suppler_ID int, p_First_Name_Repres varchar (30), p_Second_Name_Repres varchar (30),
p_Middle_Name_Repres varchar (30))
language plpgsql
as $$
	declare p_exsit_record int := count(*) from Representative
	where Suppler_ID = p_Suppler_ID and First_Name_Repres = p_First_Name_Repres and Second_Name_Repres = p_Second_Name_Repres and p_Middle_Name_Repres;
	begin
		if (p_exsit_record > 0) then
			raise notice 'В данный представитель уже есть в данной фирме!';
		else
			if (p_Middle_Name_Repres = '') or (p_Middle_Name_Repres = ' ') then
				update Representative set
					Suppler_ID = p_Suppler_ID,
					First_Name_Repres = p_First_Name_Repres,
					Second_Name_Repres = p_Second_Name_Repres
						where
							ID_Representative = p_ID_Representative;
			else  
				update Representative set
					Suppler_ID = p_Suppler_ID,
					First_Name_Repres = p_First_Name_Repres,
					Second_Name_Repres = p_Second_Name_Repres,
					Middle_Name_Repres = p_Middle_Name_Repres
						where
							ID_Representative = p_ID_Representative;
			end if;
		end if;
	end;
$$;

create or replace procedure Representative_delete (p_ID_Representative int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Treaty
	where Representative_ID = p_ID_Representative;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Представитель не может быть удален, так как в таблице "Договор", есть связанные данные!"';
		else
			delete from Representative 
				where
					ID_Representative = p_ID_Representative;
		end if;
	end;
$$;

create or replace procedure Treaty_insert (p_Treaty_Number varchar (15), p_Urgent varchar (3), p_Term varchar (15), p_Representative_ID int)
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Treaty_Number = '__________-__-Д') or (p_Treaty_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Treaty;
			p_step := 10 - length(@Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			insert into Treaty (Treaty_Number, Urgent, Term, Representative_ID)
			values (p_new_Number||p_Part_Number||'-'||SUBSTRING(current_date::varchar from 3 for 2)||'-Д', p_Urgent, p_Term, p_Representative_ID);
		else
			insert into Treaty (Treaty_Number, Urgent, Term, Representative_ID)
			values (p_Treaty_Number, p_Urgent, p_Term, p_Representative_ID);
		end if;
		exception when others
		then
			raise notice 'Данный номер договора уже есть в таблице!';
		end;	
$$;

create or replace procedure Treaty_update (p_ID_Treaty int, p_Treaty_Number varchar (15), p_Urgent varchar (3), p_Term varchar (15), p_Representative_ID int)
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Treaty_Number = '__________-__-Д') or (p_Treaty_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Treaty;
			p_step := 10 - length(@Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			update Treaty set
				Treaty_Number = p_Treaty_Number,
				Urgent = p_Urgent,
				Term = p_Term,
				Representative_ID =p_new_Number||p_Part_Number||'-'||SUBSTRING(current_date::varchar from 3 for 2)||'-Д'
					where
						ID_Treaty = p_ID_Treaty;
		else
			update Treaty set
				Treaty_Number = p_Treaty_Number,
				Urgent = p_Urgent,
				Term = p_Term,
				Representative_ID =p_Representative_ID
					where
						ID_Treaty = p_ID_Treaty;
		end if;
		exception when others
		then
			raise notice 'Данный номер договора уже есть в таблице!';
		end;	
$$;

create or replace procedure Treaty_delete (p_ID_Treaty int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Supply
	where Treaty_ID = p_ID_Treaty;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Договор не может быть удален, так как в таблице "Поставка", есть связанные данные!"';
		else
			delete from Treaty
				where
					ID_Treaty = p_ID_Treaty;
		end if;
	end;
$$;

create or replace procedure Buyer_Card_insert (p_Card_Number varchar (19), p_Card_Holder varchar (60), p_Validity varchar (5),
p_Buyer_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Buyer_Card
	where Card_Number = p_Card_Number and Buyer_ID = p_Buyer_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'У данного клиента уже есть указанная банковская карта!';
		else
			insert into Buyer_Card (Card_Number, Card_Holder, Validity, Buyer_ID)
			values (p_Card_Number, p_Card_Holder, p_Validity, p_Buyer_ID);
		end if;
		exception when others
		then
			raise notice 'Указанная бакоковская карта уже есть в таблице!';
		end;	
$$;

create or replace procedure Buyer_Card_update (p_ID_Buyer_Card int, p_Card_Number varchar (19), p_Card_Holder varchar (60), p_Validity varchar (5),
p_Buyer_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Buyer_Card
	where Card_Number = p_Card_Number and Buyer_ID = p_Buyer_ID;
	begin
		if (@exist_record > 0) then
			raise notice 'У данного клиента уже есть указанная банковская карта!';
		else
			update Buyer_Card set
				Card_Number = p_Card_Number,
				Card_Holder = p_Card_Holder,
				Validity = p_Validity,
				Buyer_ID = p_Buyer_ID
					where
						ID_Buyer_Card = p_ID_Buyer_Card;
		end if;
		exception when others
		then
			raise notice 'Указанная бакоковская карта уже есть в таблице!';
		end;	
$$;

create or replace procedure Buyer_Card_delete (p_ID_Buyer_Card int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Sale_Check
	where Buyer_Card_ID = p_ID_Buyer_Card;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Карта клиента не может быть удалена, так как в таблице "Товарный чек", есть связанные данные!"';
		else
			delete from Buyer_Card 
				where
					ID_Buyer_Card = p_ID_Buyer_Card;
		end if;
	end;
$$;

create or replace procedure Combination_insert (p_Post_ID int, p_Employee_ID int)
language plpgsql
as $$
	declare p_exist_rectord int := count(*) from  Combination 
	where Post_ID = p_Post_ID and Employee_ID = p_Employee_ID;
	begin
		if (@exist_rectord > 0 ) then
			raise notice 'Указанная должность уже имеется у сотрудника!';
		else
			insert into Combination (Post_ID, Employee_ID)
			values (p_Post_ID, p_Employee_ID);
		end if;
	end;
$$;

create or replace procedure Combination_update (p_ID_Combination int, p_Post_ID int, p_Employee_ID int)
language plpgsql
as $$
	declare p_exist_rectord int := count(*) from  Combination
	where Post_ID = p_Post_ID and Employee_ID = p_Employee_ID;
	begin
		if (p_exist_rectord > 0 ) then
			raise notice 'Указанная должность уже имеется у сотрудника!';
		else
			update Combination set
				Post_ID = p_Post_ID,
				Employee_ID = p_Employee_ID
					where
						ID_Combination = p_ID_Combination;
		end if;
	end;
$$;

create or replace procedure Combination_delete (p_ID_Combination int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Employee_Change
	where Combination_ID = p_ID_Combination;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Совместительство не может быть удалено, так как в таблице "Смена сотрудника", есть связанные данные!"';
		else
			delete from Combination
				where
					ID_Combination = p_ID_Combination;
		end if;
	end;
$$;

create or replace procedure Employee_Change_insert (p_Combination_ID int, p_Cash_Machine_ID int)
language plpgsql
as $$
	declare p_new_Number varchar (11);
	declare p_Part_Number varchar (11);
	declare p_step int;
	begin
		p_new_Number = '';
		p_Part_Number := count(*)+1 from Treaty;
		p_step := 11 - length(p_Part_Number);
			for i in 1..p_step loop
				p_new_Number = p_new_Number||'0';
			end loop;
		insert into Employee_Change (Employee_Change_Number, Combination_ID, Cash_Machine_ID)
		values (p_new_Number||p_Part_Number, p_Combination_ID, p_Cash_Machine_ID);
		exception when others
		then
			raise notice 'Данный номер смены уже имеется в системе';
		end;	
$$;

create or replace procedure Employee_Change_delete (p_ID_Employee_Change int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Sale_Check
	where Employee_Change_ID = p_ID_Employee_Change;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Смена не может быть удалена, так как в таблице "Товарный чек", есть связанные данные!"';
		else
			delete from Employee_Change 
				where
				ID_Employee_Change = p_ID_Employee_Change;
		end if;
	end;
$$;

create or replace procedure Product_insert (p_Price_Product decimal (38,2), p_Product_Name varchar (50), p_Compound varchar,
p_End_Date date, p_Vendor_Code varchar (13), p_Type_Product_ID int, p_Manufacturer_ID int)
language plpgsql
as $$
	begin
		insert into Product (Price_Product, Product_Name, Compound, End_Date, Vendor_Code, Type_Product_ID, Manufacturer_ID)
	values (p_Price_Product, p_Product_Name, p_Compound, p_End_Date, p_Vendor_Code, p_Type_Product_ID, p_Manufacturer_ID);
		exception when others
		then
			raise notice 'Ошибка при вводе данных о товаре!';
		end;	
$$;

create or replace procedure Product_update (p_ID_Product int, p_Price_Product decimal (38,2), p_Product_Name varchar (50), p_Compound varchar,
p_End_Date date, p_Vendor_Code varchar (13), p_Type_Product_ID int, p_Manufacturer_ID int)
language plpgsql
as $$
	begin
		update Product set
			Price_Product = p_Price_Product,
			Product_Name = p_Product_Name,
			Compound = p_Compound,
			End_Date = p_End_Date,
			Vendor_Code = p_Vendor_Code,
			Type_Product_ID = p_Type_Product_ID,
			Manufacturer_ID = p_Manufacturer_ID
				where
					ID_Product = p_ID_Product;
		exception when others
		then
			raise notice 'Ошибка при вводе данных о товаре!';
		end;	
$$;

create or replace procedure Product_delete (p_ID_Product int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Product
	inner join Cancellation_View on ID_Product = Cancellation_View.Product_ID
	inner join Product_List_View on ID_Product = Product_List_View.Product_ID
	inner join Sale_Check_View on ID_Product = Sale_Check_View.Product_ID
	inner join Supply_View on ID_Product = Supply_View.Product_ID 
	where Cancellation_View.Product_ID = p_ID_Product or Product_List_View.Product_ID = p_ID_Product 
	or Sale_Check_View.Product_ID = p_ID_Product or Supply_View.Product_ID = p_ID_Product;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Продукт не может быть удален, так как в одной из таблиц: "Состав акта возврата", "Состав сметы", "Состав чека" или "Состав поставки", есть связанные данные!"';
		else
			delete from Product 
				where
					ID_Product = p_ID_Product;
		end if;
	end;
$$;

create or replace procedure Product_List_View_insert (p_Product_List_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Product_List_View
	where Product_List_ID = p_Product_List_ID and Product_ID = p_Product_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный товар уже есть в заявке!';
		else
			insert into Product_List_View (Product_List_ID, Product_ID)
			values (p_Product_List_ID, p_Product_ID);
		end if;
	end;
$$;

create or replace procedure Product_List_View_update (p_ID_Product_List_View int, p_Product_List_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Product_List_View
	where Product_List_ID = p_Product_List_ID and Product_ID = p_Product_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный товар уже есть в заявке!';
		else
			update Product_List_View set
				Product_List_ID = p_Product_List_ID,
				Product_ID = p_Product_ID
					where
						ID_Product_List_View = p_ID_Product_List_View ;
		end if;
	end;
$$;

create or replace procedure Product_List_View_delete (p_ID_Product_List_View int)
language plpgsql
as $$
	begin
		delete from Product_List_View 
			where
				ID_Product_List_View = p_ID_Product_List_View;
	end;
$$;

create or replace procedure Cancellation_View_insert (p_Cancellation_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Cancellation_View
	where Cancellation_ID = p_Cancellation_ID and Product_ID = p_Product_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'В указанном акте уже имеется данный товар!';
		else
			insert into Cancellation_View (Cancellation_ID, Product_ID)
			values (p_Cancellation_ID, p_Product_ID);
		end if;
	end;
$$;

create or replace procedure Cancellation_View_update (p_ID_Cancellation_View int, p_Cancellation_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Cancellation_View
	where Cancellation_ID = p_Cancellation_ID and Product_ID = p_Product_ID;
	begin
		if (p_exist_record > 0) then
			raise notice 'В указанном акте уже имеется данный товар!';
		else
			update Cancellation_View set
				Cancellation_ID = p_Cancellation_ID,
				Product_ID = p_Product_ID
					where
						ID_Cancellation_View = p_ID_Cancellation_View;
		end if;
	end;
$$;

create or replace procedure Cancellation_View_delete (p_ID_Cancellation_View int)
language plpgsql
as $$
	begin
		delete from Cancellation_View 
			where
				ID_Cancellation_View = p_ID_Cancellation_View;
	end;
$$;

create or replace procedure Supply_insert (p_Integrity_Supply varchar (30), p_Supply_Number varchar (15), p_Treaty_ID int, p_Warehouse_ID int)
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Supply_Number = '__________-__-_') or (p_Supply_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Supply;
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			insert into Supply (Integrity_Supply, Supply_Number, Treaty_ID, Warehouse_ID)
			values (p_Integrity_Supply, p_new_Number||p_Part_Number||'-'||SUBSTRING(current_date::varchar from 3 for 2)||'-П', p_Treaty_ID, p_Warehouse_ID);
		else
			insert into Supply (Integrity_Supply, Supply_Number, Treaty_ID, Warehouse_ID)
			values (p_Integrity_Supply, p_Supply_Number, p_Treaty_ID, p_Warehouse_ID);
		end if;
		exception when others
		then
			raise notice 'Указанный номер поставки уже есть в таблице!';
		end;	
$$;

create or replace procedure Supply_update (p_ID_Supply int, p_Integrity_Supply varchar (30), p_Supply_Number varchar (15), p_Treaty_ID int, p_Warehouse_ID int)
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Supply_Number = '__________-__-_') or (p_Supply_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Supply;
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			update Supply set
				Integrity_Supply = p_Integrity_Supply,
				Supply_Number = p_new_Number||p_Part_Number||'-'||SUBSTRING(current_date::varchar from 3 for 2)||'-П',
				Treaty_ID = p_Treaty_ID,
				Warehouse_ID = p_Warehouse_ID
					where
						ID_Supply = p_ID_Supply;
		else
			update Supply set
				Integrity_Suppl = p_Integrity_Supply,
				Supply_Number = p_Supply_Number,
				Treaty_ID = p_Treaty_ID,
				Warehouse_ID = p_Warehouse_ID
					where
						ID_Supply = p_ID_Supply;
		end if;
		exception when others
		then
			raise notice 'Указанный номер поставки уже есть в таблице!';
		end;	
$$;

create or replace procedure Supply_delete (p_ID_Supply int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Supply_View
	where Supply_ID = p_ID_Supply;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Поставка не может быть удалена, так как в таблице "Состав поставки", есть связанные данные!"';
		else
			delete from Supply
				where
					ID_Supply = p_ID_Supply;
		end if;
	end;
$$;

create or replace procedure Supply_View_insert (p_Supply_Ammount int, p_Supply_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Supply_View 
	where Supply_ID = p_Supply_ID and Product_ID = p_Product_ID and Supply_Ammount = p_Supply_Ammount;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный товар уже есть в смете!';
		else
			insert into Supply_View (Supply_Ammount, Supply_ID, Product_ID)
			values (p_Supply_Ammount, p_Supply_ID, p_Product_ID);
		end if;
	end;
$$;

create or replace procedure Supply_View_update (p_ID_Supply_View int, p_Supply_Ammount int, p_Supply_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_exist_record int := count(*) from Supply_View 
	where Supply_ID = p_Supply_ID and Product_ID = p_Product_ID and Supply_Ammount = p_Supply_Ammount;
	begin
		if (p_exist_record > 0) then
			raise notice 'Указанный товар уже есть в смете!';
		else
			update Supply_View set
				Supply_Ammount = p_Supply_Ammount,
				Supply_ID = p_Supply_ID,
				Product_ID = p_Product_ID
					where
						ID_Supply_View = p_ID_Supply_View;
		end if;
	end;
$$;

create or replace procedure Supply_View_delete (p_ID_Supply_View int)
language plpgsql
as $$
	begin
		delete from Supply_View
			where
				ID_Supply_View = p_ID_Supply_View;
	end;
$$;

create or replace procedure Sale_Check_insert (p_Sale_Check_Number varchar (14), p_Deposited_Ammount decimal (38,2), p_Whith_VAT decimal (38,2),
p_Without_VAT decimal (38,2), p_Payment_Type_ID int,
p_Employee_Change_ID int, p_Buyer_Card_ID int)
language plpgsql
as $$
	declare p_new_Number varchar (10);
	declare p_Part_Number varchar (10);
	declare p_step int;
	begin
		if (p_Sale_Check_Number = '_________-__') or (p_Sale_Check_Number = ' ') then
			p_new_Number := '';
			p_Part_Number := count(*)+1 from Sale_Check;
			p_step := 10 - length(p_Part_Number);
				for i in 1..p_step loop
					p_new_Number := p_new_Number||'0';
				end loop;
			insert into Sale_Check (Sale_Check_Number, Deposited_Ammount, Whith_VAT, Without_VAT, Payment_Type_ID, Employee_Change_ID, Buyer_Card_ID)
			values (p_new_Number||p_Part_Number||'-ФК', p_Deposited_Ammount, p_Whith_VAT, p_Without_VAT, p_Payment_Type_ID, p_Employee_Change_ID, p_Buyer_Card_ID);
		else
			insert into Sale_Check (Sale_Check_Number, Deposited_Ammount, Whith_VAT, Without_VAT, Payment_Type_ID, Employee_Change_ID, Buyer_Card_ID)
			values (p_Sale_Check_Number, p_Deposited_Ammount, p_Whith_VAT, p_Without_VAT, p_Payment_Type_ID, p_Employee_Change_ID, p_Buyer_Card_ID);
		end if;
		exception when others
		then
			raise notice 'Указанный номер чека уже есть в таблице!';
		end;	
$$;

create or replace procedure Sale_Check_delete (p_ID_Sale_Check int)
language plpgsql
as $$
	declare p_any_child_record int := count(*) from Sale_Check_View
	where Sale_Check_ID = p_ID_Sale_Check;
	begin
		if (p_any_child_record > 0 ) then
			raise notice 'Товарный чек не может быть удален, так как в таблице "Состав товарного чека", есть связанные данные!"';
		else
			delete from Sale_Check
				where
					ID_Sale_Check = p_ID_Sale_Check;
			end if;
	end;
$$;

create or replace procedure Sale_Check_View_Work (p_Sale_Check_ID int, p_Product_ID int)
language plpgsql
as $$
	declare p_ID_sale_check_view int := ID_Sale_Check_View from Sale_Check_View 
	where Sale_Check_ID = p_Sale_Check_ID and Product_ID = p_Product_ID;
	begin
		if (p_ID_sale_check_view is null) then
			insert into Sale_Check_View (Sale_Check_View_Ammount, Sale_Check_ID, Product_ID)
			values (1, p_Sale_Check_ID, p_Product_ID);
		else
			update Sale_Check_View set
				Sale_Check_View_Ammount = Sale_Check_View_Ammount + 1,
				Sale_Check_ID = p_Sale_Check_ID,
				Product_ID = p_Product_ID
					where
						ID_Sale_Check_View = p_ID_sale_check_view;
		end if;
	end;
$$;

create or replace procedure Sale_Check_View_delete (p_ID_Sale_Check_View int)
language plpgsql
as $$
	begin
		delete from Sale_Check_View
			where
			ID_Sale_Check_View = p_ID_Sale_Check_View;
	end;
$$;

call Type_Product_insert('Бытовая химия');
select * from Type_Product;

call Type_Product_update(5,'Химическая продукция');
select * from Type_Product;

call Type_Product_delete(5);
select * from Type_Product;

call Type_Product_delete(1);
select * from Type_Product;

call Type_Product_insert('Мясное изделье');
select * from Type_Product;

call Cash_Machine_insert(' ');
select * from Cash_Machine;


SELECT count(*) FROM information_schema.routines 
WHERE routine_type = 'PROCEDURE';